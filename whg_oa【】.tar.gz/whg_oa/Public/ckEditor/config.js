/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

 CKEDITOR.editorConfig = function( config ) {
 	config.language = 'zh-cn';
	//config.uiColor = '#F7B42C';
	config.height = '650';
	config.toolbarCanCollapse = true;

	config.filebrowserImageUploadUrl=uploadfile;
	config.toolbarGroups = [
	'/',
	{ name: 'styles', groups: [ 'styles' ] },
	{ name: 'clipboard', groups: [ 'undo', 'clipboard' ] },
	{ name: 'editing', groups: [ 'find', 'selection', 'spellchecker', 'editing' ] },
	{ name: 'forms', groups: [ 'forms' ] },
	'/',
	{ name: 'basicstyles', groups: [ 'cleanup', 'basicstyles' ] },
	{ name: 'paragraph', groups: [ 'align', 'indent', 'list', 'blocks', 'bidi', 'paragraph' ] },
	{ name: 'links', groups: [ 'links' ] },
	{ name: 'insert', groups: [ 'insert' ] },
	{ name: 'colors', groups: [ 'colors' ] },
	{ name: 'tools', groups: [ 'tools' ] },
	{ name: 'others', groups: [ 'others' ] },
	{ name: 'about', groups: [ 'about' ] },
	{ name: 'document', groups: [ 'mode', 'document', 'doctools' ] }
	];

	config.removeButtons = 'Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField,CreateDiv,Blockquote,Anchor,About';
};

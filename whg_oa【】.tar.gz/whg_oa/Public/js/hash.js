//hash.js
checkURL();
$(window).on('hashchange', function() { checkURL(); })
$(document).on("click", 'a[href="#"]', function(e) { e.preventDefault(); });
$('li.first-bar').on('click', function() {
    var kind = $(this).hasClass('parent');
    if (kind == false) {
        $('li.first-bar').removeClass('active');
        $(this).addClass('active');
        $('ul.children').slideUp();
        $('.children li').removeClass('active');
    }
})
$('.ajax-fade').click(function() {
    $(this).fadeOut('fast');
    $('#contentBox .panel-heading').html('');
    $('#contentBox .content').html('');
})
$('#contentBox').click(function(e) { e.stopPropagation(); })
/*改变hash尾巴*/
function checkURL() {
    firstFlag=true;
    var arr = location.href.split("#");
    var hash = '';
    if (arr.length > 1) {
        hash = arr[1];
    }
    if (hash != '') {
        loadURL(hash);
    } else {
     loadURL(common_conf.defaultHash);
 }
}
/*ajax弹窗*/
function ajaxFill(url, title) {
    $('.ajax-fade').show();
    $('#contentBox').addClass('animated fadeInDown speed');
    $('#contentBox .panel-heading').html('');
    $('#contentBox .content').html('');
    setTimeout(function() {
        $('#contentBox').removeClass('animated fadeInDown speed');
    }, 600);
    var newUrl = common_conf.baseURL + url;
    //console.log(newUrl);
    $.ajax({
        url: newUrl,
        dataType: 'html',
        type: 'get',
        success: function(returnData) {
            if (title) {
                $('#contentBox .panel-heading').html(title);
            } else {
                $('#contentBox .panel-heading').html('操作');
            }
            $('#contentBox .content').html(returnData);
        }
    })
}

function delBind() {
    $('.label-del').unbind('click').bind('click',function(){
        $(this).closest('.group-label').remove();
        var val = $(this).closest('.group-label').find('span').html();
        var grouparr = [];//选中的部门
        for (var k = 0; k < $('.group-label').length; k++) {
            grouparr.push($('.group-label').eq(k).find('span').html());
        }
        $('.inner .jobid').hide();

        //文本框里的字
        var showdname = $('.filter-option').html();
        var newshowdname=showdname.replace(/\s/g,'');
        var showqwe=newshowdname.split(',');

        $('.inner .jobid').each(function(){
         var dname=  $(this).find('span').html();
         var arr = dname.split('-');
         var group=arr[0];
         if ($.inArray(group, grouparr)!=-1) {
            $(this).show();
        }else{
         if($.inArray(dname, showqwe)!=-1){
            $(this).click();
        }
        $(this).hide();
    }
});

//         for (var i = 0; i < $('.inner .jobid').length; i++) {
//         //下拉列表中的字
//         var dname=$('.inner .jobid').eq(i).find('span').html();
//         var arr = dname.split('-');



//         console.log(arr[0]);
//         console.log(val);
//         console.log(formatarr);
//         console.log(grouparr);
//         console.log(i)
//         console.log('**************************');
//         if($.inArray(arr[0], grouparr)!=-1){
//             $('.inner .jobid').eq(i).show();
//         }
//         if($.inArray(val, formatarr)!=-1){
//             $('.inner .jobid').eq(i).show();
//         }
//      //    if(formatarr!=''){
//      //        if(grouparr!=''){
//      //            if(val==arr[0]){
//      //             $('.inner .jobid').eq(i).click();
//      //         }
//      //     }
//      // }

// };
if($('[data-id="position"]').find('span.filter-option').text()=='Nothing selected'){
    $('[data-id="position"]').find('span.filter-option').html('请选择职务');
}
})
}
/*异步加载页面到容器中*/
function loadURL(url) {
    var content = $('#container');
    var target = common_conf.baseURL + url;
    $.ajax({
        url: target,
        type: 'get',
        cache: false,
        dataType: 'html',
        beforeSend: function() {
            window.location.hash = url;
            $('.pageloading').show();
        },
        success: function(returnData) {
            setTimeout(function() {
                var aa = $('a[href="#' + url + '"]:eq(0)');
                aa.closest('li').trigger('click');
                $('.pageloading').hide();
                content.css('opacity', 0).html(returnData);
                content.animate({ 'opacity': 1 }, { queue: false, duration: 200 });
            }, 400);
        },
        error: function() {
            content.html('Error 404! 页面不存在');
        }
    })
}
/*弹出层*/
function showToastr(msg, title, status) {
    toastr.options = {
        "closeButton": true,
        "debug": false,
        "positionClass": "toast-top-center",
        "onclick": null,
        "showDuration": "1000",
        "hideDuration": "1000",
        "timeOut": "2500",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }

    if (typeof msg == 'undefined') msg = '操作成功';
    if (typeof status == 'undefined') status = 1;
    if (status == 1) {
        toastr.success(msg, title);
    } else if (status == 0) {
        toastr.error(msg, title);
    } else {
        toastr.info(msg, title);
    }
    // if(url!='' && typeof url!='undefined'){
    //   setTimeout(function(){$('#jumpBridge').attr('href', url).trigger('click');},100);
    // }
    //if(typeof delay!='undefined') setTimeout("window.location.reload()", 1000*delay);
}
//拖拽
function dragAndDrop(){
  var _move = false;//移动标记
  var _x,_y;//鼠标离控件左上角的相对位置
  $(".move-header").mousedown(function(e){
    _move=true;
    _x=e.pageX-parseInt($(".move-box").css("left"));
    _y=e.pageY-parseInt($(".move-box").css("top"));
    //$(".wTop").fadeTo(20,0.5);//点击开始拖动并透明显示
});
  $(document).mousemove(function(e){
    if(_move){
      var x=e.pageX-_x;//移动时鼠标位置计算控件左上角的绝对位置
      var y=e.pageY-_y;
      $(".move-box").css({top:y,left:x});//控件新位置
  }
}).mouseup(function(){
    _move=false;
  //$(".wTop").fadeTo("fast",1);//松开鼠标后停止移动并恢复成不透明
});
}
//初始化拖拽div的位置
function initPosition(){
  //计算初始化位置
  var itop=($(document).height()-$(".move-box").height())/2;
  var ileft=($(document).width()-$(".move-box").width())/1.8;
  //设置被拖拽div的位置
  $(".move-box").css({top:itop,left:ileft});
}

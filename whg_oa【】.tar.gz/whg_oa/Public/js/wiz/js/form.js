//表单提交ajax处理
$(function () {
    $("#signupok").submit( function () {
        $.ajax({
            type: "POST",
            cache: false,
            url:$(this).attr('action'),
            data:$(this).serialize(),
            dataType:'json',
            success: function (res) {
                if(res.status){
                    alert(res.info);
                    //alert(site_url);
                    window.location.href=site_url;
                }else{

                    alert(res.info);
                }
            },
            error: function () {
                alert('请求页面失败!');
                return false;
            }
        });
        return false;
    } );
});


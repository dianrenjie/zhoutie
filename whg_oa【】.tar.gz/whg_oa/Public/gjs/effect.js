// JavaScript Document
$(function(){

})
var setTimeoutalltip;
//引入底部
function includeFooter(num){
	var html="";
		html+="<footer class=\"main_footer\">";
		html+="<a href=\"member_center.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe66c;</i><p>精选</p></a>";
		html+="<a href=\"sign.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe670;</i><p>发现</p></a>";
		html+="<a href=\"pointsShops.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe666;</i><p>购物车</p></a>";
		html+="<a href=\"member_ifrom.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe66d;</i><p>我的</p></a>";
		html+="</footer>";
	$('body').append(html);
	$('.main_footer a').eq(num-1).addClass('active');
}
//引入禁止手机横屏
function includeMask(){
	var html="";
	    html+="<div class=\"mask flexcontainer\" id=\"all_mask\">";
			html+="<div class=\"mask-box\">";
			html+="<div class=\"mask-pic\">";
			html+="<i></i>";
			html+="</div>";
			html+="<span>为了更好的体验，请将手机/平板竖过来</span>";
			html+="</div>";
			html+="</div>";
	$('body').append(html);
}
//引入顶部
function includeToper(){
	var html="";
		html+="<div class=\"Tops\">";
		html+="<a href=\"javascript:history.go(-1);\"><img src=\"img/b5.png\"/></a>提交订单<p></p>";
		html+="</div>";
	$('body').append(html);
}
//是否微信、pc
function is_weixn(){
    var ua = navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i)=="micromessenger") {
		//touchFade();
        return true;
    } else {
		//showFade();
    }
}
/*回到顶部*/
function backTop(view){
   $(''+view+'').animate({scrollTop:0},200);
}
//默认页面沉底方法
function tops(){
	$('.chats').scrollTop(1000000);
}
//操作提示
function alltip(text) {
    clearTimeout(setTimeoutalltip);
    $('.tipfade').hide();
    $('.tipfade').show();
    $('.tipspan').text(text).fadeInDown();
    setTimeoutalltip = setTimeout(function() { $('.tipfade').fadeOut(); }, 2000);
}


//向上弹出
jQuery.fn.slideUp = function () {
	var flag=$(this).hasClass('animated slideUp speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideUp speed');
	}else{
		ele.addClass('animated slideUp speed');
		setTimeout(function(){
			ele.css('transform','translateX(0%)');
			ele.removeClass('animated slideUp speed');
		},600);
	}
}
//向下收回
jQuery.fn.slideDown = function () {
	var flag=$(this).hasClass('animated slideDown speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideDown speed');
	}else{
		ele.addClass('animated slideDown speed');
		setTimeout(function(){
			ele.css('transform','translateX(100%)');
			ele.removeClass('animated slideDown speed');
		},600);
	}
}
//向左边弹出
jQuery.fn.slideLeft = function () {
	var flag=$(this).hasClass('animated slideLeft speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideLeft speed');
	}else{
		ele.addClass('animated slideLeft speed');
		setTimeout(function(){
			ele.css('transform','translateX(0%)');
			ele.removeClass('animated slideLeft speed');
		},600);
	}
}
//向右边弹回
jQuery.fn.slideRight = function () {
	var flag=$(this).hasClass('animated slideRight speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideRight speed');
	}else{
		ele.addClass('animated slideRight speed');
		setTimeout(function(){
			ele.css('transform','translateX(100%)');
			ele.removeClass('animated slideRight speed');
		},600);
	}
}
//渐入效果
jQuery.fn.fadeInDown = function () {
	var flag=$(this).hasClass('animated fadeInDown speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeInDown speed');
	}else{
		$(this).addClass('animated fadeInDown speed');
		setTimeout(function(){
			ele.removeClass('animated fadeInDown speed');
		},600);
	}
}

//弹性放大效果
jQuery.fn.bounceIn = function () {
	var flag=$(this).hasClass('animated bounceIn speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated bounceIn speed');
	}else{
		$(this).addClass('animated bounceIn speed');
		setTimeout(function(){
			ele.removeClass('animated bounceIn speed');
		},600);
	}
}
//渐出效果
jQuery.fn.fadeOutUp = function () {
	var flag=$(this).hasClass('animated fadeOutUp speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeOutUp speed');
	}else{
		$(this).addClass('animated fadeOutUp speed');
		setTimeout(function(){
			ele.hide().removeClass('animated fadeOutUp speed');
		},600);
	}
}
//从右渐入效果
jQuery.fn.fadeInRight = function () {
	var flag=$(this).hasClass('animated fadeInRight speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeInRight speed');
	}else{
		$(this).addClass('animated fadeInRight speed');
		setTimeout(function(){
			ele.removeClass('animated fadeInRight speed');
		},600);
	}
}
//向右渐出效果
jQuery.fn.fadeOutRight = function () {
	var flag=$(this).hasClass('animated fadeOutRight speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeOutRight speed');
	}else{
		$(this).addClass('animated fadeOutRight speed');
		setTimeout(function(){
			ele.hide().removeClass('animated fadeOutRight speed');
		},600);
	}
}
//向左渐出效果
jQuery.fn.fadeOutLeft = function () {
	var flag=$(this).hasClass('animated fadeOutLeft speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeOutLeft speed');
	}else{
		$(this).addClass('animated fadeOutLeft speed');
		setTimeout(function(){
			ele.hide().removeClass('animated fadeOutLeft speed');
		},600);
	}
}
//从左渐入效果
jQuery.fn.fadeInLeft = function () {
	var flag=$(this).hasClass('animated fadeInRight speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeInLeft speed');
	}else{
		$(this).addClass('animated fadeInLeft speed');
		setTimeout(function(){
			ele.removeClass('animated fadeInLeft speed');
		},600);
	}
}

//
jQuery.fn.touched = function () {
	$(this).on('touchstart',function(){
		$(this).addClass('scaleBig');
	});
	$(this).on('touchend',function(){
		$(this).removeClass('scaleBig');
	})
}
//
jQuery.fn.touchedImg = function () {
	$(this).bind('click',function(){
		var imgSrc=$(this).attr('src');
		var ele=$(this);
		var html="";
			html+="<div class=\"fadeImg\">";
			html+="<a><img class=\"fadePic\" src=\" "+imgSrc+" \"/></a></div>";
		$('body').append(html);
		//touchEvent.doubleTap(ele);
	})
}
//把一个元素放在屏幕的中心位置：$(element).center();
jQuery.fn.center = function () {
	this.css('margin-top', ( $(window).height() - this.height() ) / 2 +$(window).scrollTop() + 'px');
	return;
}
jQuery.fn.centerTop = function () {
	var that=$(this);
	setTimeout(function(){
		var h=that.css('height');
			h=h.replace(/[^0-9]+/g, '');
			h2='-'+(h/2)+'px';
			that.css('margin-top',h2);
	},0);
	return;
}
//坐标
function joinCar(){
	var cont=$(".mywrits");
	var contW=$(".mywrits").width();
	var contH=$(".mywrits").height();
	var startX,startY,sX,sY,moveX,moveY;
	var winW=$(window).width();
	var winH=$(window).height();
	$(".mywrits").on({//绑定事件
		touchstart:function(e){
			startX = e.originalEvent.targetTouches[0].pageX;	//获取点击点的X坐标
			startY = e.originalEvent.targetTouches[0].pageY;    //获取点击点的Y坐标
			//console.log("startX="+startX+"************startY="+startY);
			sX=$(this).offset().left;//相对于当前窗口X轴的偏移量
			sY=$(this).offset().top;//相对于当前窗口Y轴的偏移量
			//console.log("sX="+sX+"***************sY="+sY);
			leftX=startX-sX;//鼠标所能移动的最左端是当前鼠标距div左边距的位置
			rightX=winW-contW+leftX;//鼠标所能移动的最右端是当前窗口距离减去鼠标距div最右端位置
			topY=startY-sY;//鼠标所能移动最上端是当前鼠标距div上边距的位置
			bottomY=winH-contH+topY;//鼠标所能移动最下端是当前窗口距离减去鼠标距div最下端位置
			},
		touchmove:function(e){
			e.preventDefault();
			moveX=e.originalEvent.targetTouches[0].pageX;//移动过程中X轴的坐标
			moveY=e.originalEvent.targetTouches[0].pageY;//移动过程中Y轴的坐标
			//console.log("moveX="+moveX+"************moveY="+moveY);
			if(moveX<leftX){moveX=leftX;}
			if(moveX>rightX){moveX=rightX;}
			if(moveY<topY){moveY=topY;}
			if(moveY>bottomY){moveY=bottomY;}
			$(this).css({
				"left":moveX+sX-startX,
				"top":moveY+sY-startY,
				})
			},
	})
}
//判断移动pc
function IsPC(){
   var userAgentInfo = navigator.userAgent;
   var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
   var flag = true;
   for (var v = 0; v < Agents.length; v++) {
	   if (userAgentInfo.indexOf(Agents[v]) > 0) { flag = false; break; }
   }
   if(flag==false){
   	   $('.iconfont').css('font-family','iconfont');
   }else{
   	   $('.iconfont').css('font-family','iconfont2');
   }

}
//横竖屏检测
// $(window).bind( 'orientationchange', function(e){
// 	orient();
// });

/*js判断手机横、竖屏*/
function orient() {
	if (window.orientation == 0 || window.orientation == 180) {
		//$("body").attr("class", "portrait");
		$('#mask').hide();
		orientation = 'portrait';
		console.log('竖屏');
		return false;
	}
	else if (window.orientation == 90 || window.orientation == -90) {
		//$("body").attr("class", "landscape");
		$('#mask').show();
		orientation = 'landscape';
		console.log('横屏');
		return false;
	}
}
//安卓input输入影响布局解决方案
function AndroidInput(ele){
	var viewHeight = window.innerHeight; //获取可视区域高度
	$("input").focus(function(){
	    $("."+ele+"").css("height",viewHeight);
			$('#all_mask').hide();
	}).blur(function(){
	    $("."+ele+"").css("height","100%");
	});
}
/*禁用页面滑动*/
function disabletouchmove(){
  $('body').bind('touchmove',function(e){ e.preventDefault();})
}
//加入购物车之抛物线运动及以下兼容IE9
jQuery.fn.joinCar = function (btn,cart) {
	btn.bind('click',function(event){
		var offset=cart.offset();//购物车位置
		var img=$(this).parent().find('img').attr('src');//获取当前点击图片链接
		var flyer = $('<img class="flyer-img" src="' + img + '">');//抛物体对象
		flyer.fly({
           start: {
				left: event.pageX, //抛物体起点横坐标
				top: event.pageY////抛物体起点纵坐标
           },
		   end: {
				left: offset.left + 10, //抛物体终点横坐标
				top: offset.top + 10, //抛物体终点纵坐标
		   },
		   onEnd: function() {
			//	$("#tip").show().animate({width: '200px'}, 300).fadeOut(500);//成功加入购物车动画效果
				this.destory();//销毁抛物体
		   }
		});
	})
}
Array.prototype.remove=function(val){
	var index=this.indexOf(val);
	if(index>-1){
		this.splice(index,1);
	}
}
/*
//调用 	loadingBox.bindScroll($('#abc'));
//为元素绑定滚动事件
var pageNo = 1;
var pageflag = true;
var xg = true;
var loadtime = 0;
//加载更多
var loadingBox= {
	bindScroll:function(ele){
		ele.on('scroll', function() {
			var scrollHeight = $(this)[0].scrollHeight;
			var scrollTop = $(this)[0].scrollTop;　
			var nDivHight = $(this).height();
			if (pageflag == true && scrollTop + nDivHight > scrollHeight - 30) {
				xg = false;
				if (loadtime == 0) {
					$('[data-id="load-tip"]').append('<span><i></i></span>');
					loadtime++;
				} else {
					$('[data-id="load-tip"]').html('<span><i></i></span>');
				}
				setTimeout('loadingBox.addPageSize()', 1000);
				pageflag = false;
			}
		});
	},
	addPageSize:function(){
		pageNo += 1;
		console.log('页数'+pageNo);
		loadingBox.loadBoxs();
		pageflag = true;
	},
	loadBoxs:function(){
		$.ajax({
			url: "",
			dataType: 'json',
			data: {
				pageSize: 4,
				pageNo: pageNo,
			},
			success: function(data) {
				if (data != null) {
					var html = "";
					for (var i = 0; i < data.length; i++) {
						var listImg = data[i].img; //图片路劲
						var listPoints = data[i].points;//积分
						var listTitle = data[i].tltle; //说明

						html += "<li><i><img src=\" "+listImg+" \"/></i>";
						html += "<p>积分:"+listPoints+"</p><a>"+listTitle+"</a></li>";

					}
					$('[data-id="load-ul"]').append(html);
				} else if (data == null) {
					if (xg == true) {
					   $('[data-id="load-ul"]').html('暂无商品=.=!');
					} else {
						$('[data-id="load-tip"] span').html('没有更多喽=.=!');
					}
				};
			}//success
		});//ajax
	}

}

*/

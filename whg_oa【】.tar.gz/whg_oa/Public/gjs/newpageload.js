var index=0,question_text,answer_text,question_time=30,start;
							var moneyArr=[1,5.20,13.14,19.99];
							var question;

							$(function(){
								FastClick.attach(document.body);
								/*添加hashchange事件*/
								$(window).on('hashchange',function(e){showTab()});
								$('.start_btn').click(function(){
									$.ajax({
										url:"/index.php?g=Wap&m=Poetryanswer&a=comeback",
										dataType:'json',
										success:function(data){
											if(data.status==1){
												$('.page_index').fadeOut();
												$('.page_question').fadeIn();
												question=data.info;
												loadQuestion();
												update_time();
											}else{
												alert(data.info);
											}
										}
									})
								})
								$('.next_btn').click(function(){checkQuestion()});
								$('.activity_rule').click(function(){showTab2()});
								$('.continue').click(function(){
									$('#right').hide();
									start=setTimeout("update_time()",1000);
									loadQuestion();
								});
								$('.leave').click(function(){
									var no=Number($('.question_no').text());
									getmoney(no);
								})
								$('.agin').click(function(){ window.location.href="/index.php?g=Wap&m=Poetryanswer&a=index"; })
							})

function showTab() {
	var hash = window.location.hash;
	if (hash == "#pay_money"){
		showTab2();
	} else {
		showTab1();
	}
}
/*收回游戏规则模块*/
function showTab1() {
	$('#page_rule').slideRight();
}
/*弹出游戏规则模块*/
function showTab2() {
	$('#page_rule').slideLeft();
	window.history.pushState('forward', null, '#member_center');
};
//加载题目
function loadQuestion(){
	var state=parseInt(2*Math.random());
	var no=Number($('.question_no').text());
	if(no==5||no==10){index=0;}
	question_time=30;
	$('.timer').text(question_time);
	no+=1;
	$('.question_no').text(no);
	level(state);
	$('[data-type='+state+']').find('.question-span').text(question_text);

}
//检测题目是否答对
function checkQuestion(){
	var userAnswer=$('[data-state="true"]').val();
	var no=Number($('.question_no').text());
	if(userAnswer==answer_text){
		$('.answer_input').val('');
		index+=1;
		if(no==2||no==5||no==10||no==15){
			kindmoney(no);
			subResult(no);
			clearTimeout(start);
		}else{
			loadQuestion();
		}
	}else{
		clearTimeout(start);
		$('#wrong').show();
		$('#wrong .tip_div').fadeInDown();
	}
}
/*拿钱走人*/
function getmoney(stage){
	var aa=confirm('确定拿钱走人么？');
	if(aa==true){
		$.ajax({
			url:"/index.php?g=Wap&m=Poetryanswer&a=redenvelopes",
			dataType:'json',
			success:function(data){
				var status=data.status;
				if(status==1){
					alert('领取成功,红包将于活动结束后按顺序发送,请关注公众号消息！');
					window.location.href="/index.php?g=Wap&m=Poetryanswer&a=leaderboard";
				}else{
					alert(data.info);
				}
			}
		})
	}
}
/*区分阶段红包金额*/
function kindmoney(kind){
	if(kind==2){
		$('#right').show();
		$('#right .tip_div').fadeInDown();
		$('.tip_em').text(moneyArr[0]);
	}else if(kind==5){
		$('.tip_em').text(moneyArr[1]);
		$('#right').show();
		$('#right .tip_div').fadeInDown();
	}else if(kind==10){
		$('.tip_em').text(moneyArr[2]);
		$('#right').show();
		$('#right .tip_div').fadeInDown();
	}else{
		$('#complete').show();
		$('#complete .tip_div').fadeInDown();
	}
	
}

/*答题倒计时*/
function update_time(){
	question_time-=1;
	if(question_time==0){
		$('.timer').text(0);
		$('.next_btn').trigger('click');
	}else if(question_time>0){
		$('.timer').text(question_time);
	}
	start=setTimeout("update_time()",1000);
}
//节点（答题错误或者全部答完时触发）
function subResult(stage){
	$.ajax({
		url:"/index.php?g=Wap&m=Poetryanswer&a=node",
		dataType:'json',
		async:false,
		type:'post',
		data:{stage:stage},
		success:function(data){
			if(data.status==1){
			}else{
				alert(data.info);
				window.location.reload();
			}
		}
	})
}
//根据state以及index来对应加载题目和答案
function level(kind){
	var no=Number($('.question_no').text());
	$('.question-view').hide();
	if(kind==0){
		$('[data-type=1]').fadeOutLeft();
		$('[data-type=0]').show().fadeInRight();
		$('.question-view').find('input').attr('data-state','false');
		$('[data-type=0]').find('input').attr('data-state','true');
		if(no>0&&no<=5){
			console.log(question);
			question_text=question.easy[index].back;
			answer_text=question.easy[index].front;
		}else if(no>5&&no<=10){
			question_text=question.normal[index].back;
			answer_text=question.normal[index].front;
		}else if(no>10&&no<=15){
			question_text=question.hard[index].back;
			answer_text=question.hard[index].front;
		}
	}else{
		$('[data-type=0]').fadeOutLeft();
		$('[data-type=1]').show().fadeInRight();
		$('.question-view').find('input').attr('data-state','false');
		$('[data-type=1]').find('input').attr('data-state','true');
		if(no>0&&no<=5){
			question_text=question.easy[index].front;
			answer_text=question.easy[index].back;
		}else if(no>5&&no<=10){
			question_text=question.normal[index].front;
			answer_text=question.normal[index].back;
		}else if(no>10&&no<=15){
			question_text=question.hard[index].front;
			answer_text=question.hard[index].back;
		}
	}
	$('.span3').text(answer_text);
}
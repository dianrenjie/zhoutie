                        $(function() {
                            loadHx();
                            mvMove();
                        })


                        function mvMove() {
                            var cont = $(".dotMove");
                            var contW = $(".dotMove").width();
                            var startX, startY, sX, sY, moveX, moveY, endX;
                            var winW = $('#dot').width();
                            $(".dotMove").on({ //绑定事件
                                touchstart: function(e) {
                                    startX = e.originalEvent.targetTouches[0].pageX - 63; //获取点击点的X坐标		
                                    sX = $(this).offset().left - 63; //相对于当前窗口X轴的偏移量
                                    //console.log(startX);
                                    leftX = startX - sX; //鼠标所能移动的最左端是当前鼠标距div左边距的位置
                                    rightX = winW - contW + leftX; //鼠标所能移动的最右端是当前窗口距离减去鼠标距div最右端位置
                                },
                                touchmove: function(e) {
                                    e.preventDefault();
                                    moveX = e.originalEvent.targetTouches[0].pageX - 63; //移动过程中X轴的坐标		
                                    if (moveX < leftX) {
                                        moveX = leftX;
                                    }
                                    if (moveX > rightX) {
                                        moveX = rightX;
                                    }
                                    $(this).css({
                                        "left": moveX + sX - startX,
                                    })
                                },
                                touchend: function(e) {
                                    endX = moveX - startX;
                                    if (endX > 70) {
                                        $(this).fadeOutRight();
                                        setTimeout(function() {
                                            hexiao(); //核销影票					
                                        }, 300)
                                    } else {
                                        $(this).css({
                                            left: '14%'
                                        })
                                    }
                                }

                            })
                        }
                        //核销影票
                        function loadHx() {
                            //已核销过的
                            if (ishx == 2) {
                                $('.dotTxt').show();
                                $('.cav_dot').addClass('cav_dot_hexiao');
                                $('.dotMove').hide();
                                return;
                            }
                        }

                        function hexiao() {
                            $.ajax({
                                url: gohexiao,
                                type: "POST",
                                dataType: 'json',
                                data: {
                                    muydsz: yes
                                },
                                success: function(data) {
                                    if (data.status == 1) {
                                        $('.dotTxt').show().fadeInLeft();
                                        $('.cav_dot').addClass('cav_dot_hexiao');
                                        return;
                                    } else {
                                        alert('操作失败!!!')
                                    }

                                }
                            });
                        }

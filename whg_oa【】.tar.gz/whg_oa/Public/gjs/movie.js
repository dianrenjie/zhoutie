var startTime = $('#test').attr('startTime');
var begin = $('#test').attr('begin');

$(function() {
var acid = $('#test').attr('tssi');
    joinCar();
    //计时
    countdownTime(startTime);
    bannerBlur();
    bindClick();
    loadCinema(acid);
});
//绑定点击事件
function bindClick() {
    $('.fade_banner').click(function() {
        $(this).hide();
        $('.light_banner').fadeOutUp();
    });
    $('.fade_writ').click(function() {
        $(this).hide();
        $('.light_writ').fadeOutUp();
    });
}

var mySwiper = new Swiper(".swiper-container", {
    slidesPerView: "auto",
    centeredSlides: !0,
    watchSlidesProgress: !0,
    paginationClickable: !0,
    spaceBetween: -50,
    speed: 200,
    onProgress: function(a) {
        var b, c, d;
        for (b = 0; b < a.slides.length; b++)
            c = a.slides[b],
            d = c.progress, scale = 1 - Math.min(Math.abs(.2 * d), 1),
            es = c.style, es.opacity = 1 - Math.min(Math.abs(d / 2), 1),
            es.webkitTransform = es.MsTransform = es.msTransform = es.MozTransform = es.OTransform = es.transform = "translate3d(0px,0," + -Math.abs(200 * d) + "px)";
    },
    onSetTransition: function(a, b) {
        for (var c = 0; c < a.slides.length; c++)
            es = a.slides[c].style, es.webkitTransitionDuration = es.MsTransitionDuration = es.msTransitionDuration = es.MozTransitionDuration = es.OTransitionDuration = es.transitionDuration = b + "ms"
    }
});
//banner背景模糊
function bannerBlur() {
    var first = $('.banners .main-img').eq(0).find('img').attr('src');
    $('.bannersFade').css('background', 'url("' + first + '") repeat scroll 0 0 / cover');
    var arrImg = [];
    $.each($('a.main-img'), function(index) {
        var img = $('a.main-img').eq(index).find('img').attr('src');
        arrImg.push(img);
    });
    $('.banners').on('touchend', function() {
        var i = mySwiper.activeIndex;
        $('.bannersFade').css('background', 'url("' + arrImg[i] + '") repeat scroll 0 0 / cover');
    });

}
//打开banner电影信息
function showMovie(ele) {
    $('.fade_banner').show();
    $('.light_banner').show().fadeInDown();
    var img = $(ele).find('img').attr('src');
    var name = $(ele).attr('data-name');
    var info = $(ele).attr('data-info');
    var txt = $(ele).attr('data-txt');
    $('#lb_img').attr('src', img);
    $('#lb_name').html(name);
    $('#lb_info').html(info);
    $('#lb_txt').html(txt);
    $('.light_banner').centerTop();
}

//倒计时
//倒计时-格式-必须如下（'2017/1/6 20:30:00'）
if (begin == 0) {
    var flagRob = false;
} else {
    var flagRob = true;
}

function countdownTime(time) {
    if (flagRob == false) {
        $('#surplus').show().countdown('' + time + '', function(event) {
            $(this).html(event.strftime('%-d天%-H:%M:%S'));
        });
        $('#surplus').on('finish.countdown', function() {
            // do something...
            $('#surplus').html('抢票活动进行中！');
            alert('开始抢票吧！');
        });
    } else {
        $('#surplus').html('抢票活动进行中！');
    }
}

//加载影院信息
function loadCinema(acid) {
    $.ajax({
        url: "/index.php?g=Wap&m=Grabvotes&a=cinema",
        type: "POST",
        dataType: 'json',
        data: { id: acid },
        success: function(data) {
            if (data.status == 1) {
                var html = "";
                for (var i = 0; i < data.info.length; i++) {
                    var mtId = data.info[i].id; //影院Id
                    var mtName = data.info[i].cinemaname; //影院名
                    var mtQu = data.info[i].cinemaarea; //影院区
                    var mtArea = data.info[i].cinemaaddress; //影院具体地址
                    var mvTime = data.info[i].date; //电影时间
                    var mvName = data.info[i].moviename; //电影名
                    var mvArea = data.info[i].hall; //电影厅号
                    var mvstate = data.info[i].ishave; //是否有余票（0:可抢  1:抢光）				

                    html += "<li onClick=\"shakeDown(this,'" + mtId + "','" + mvstate + "','" + acid + "')\">";
                    html += "<i class=\"sdIcon\"></i>";
                    html += "<a>" + mvName + "</a><time>" + mvTime + "</time>";
                    html += "<span>" + mtName + "</span><p>" + mtQu + "</p>";
                    html += '<input type="hidden" data-mtArea="' + mtArea + '" data-mvTime="' + mvTime + '" data-mvName="' + mvName + '" data-mvArea="' + mvArea + '" data-mvstate="' + mvstate + '"/>';

                }
                $('.shakedown').append(html);
            } else {
                alert('影院加载失败！')
            }

        }
    });
}

//抢票数据加载
function shakeDown(ele, mtId, mvstate,acid) {
    if (mvstate == '1' && flagRob == true) {
        var html = "";
        html += "<button class=\"tp\" onclick=\"shakeWrit(this,'" + mtId + "','" + acid + "')\">立即抢票</button>";
        $('#lw_btn').html(html);
        $('#lw_mtName').html($(ele).find('span').html());
        $('#lw_mvName').html($(ele).find('a').html());
        $('#lw_mvArea').html($(ele).find('input').attr('data-mvarea'));
        $('#lw_mvTime').html($(ele).find('time').html());
        $('.fade_writ').show();
        $('.light_writ').centerTop();
        $('.light_writ').show().fadeInDown();

    }
    if (flagRob == false) {
        alert('活动未开始！');
        return;
    }
    if (mvstate == '0') {
        alert('该影院电影票已抢完,换家影院吧！');
        return;
    }
}

//抢票
function shakeWrit(ele, mtId,acid) {
    $('#lw_btn button').html('抢票中...').attr('disabled', true).addClass('btning');
    $.ajax({
        url: "/index.php?g=Wap&m=Grabvotes&a=comeback",
        dataType: 'json',
        type: "POST",
        data: { mtid: mtId, actid: acid }, //影院ID		
        success: function(data) {
            if (data.status == 1) {
                setTimeout(function() {
                    $('#lw_btn button').html('立即抢票').attr('disabled', false).removeClass('btning');
                    var flagWrit = data.info;
                    console.log(flagWrit);
                    // if(flagWrit==0){
                    alert(flagWrit);
                    $('.fade_writ').click();
                    return;
                }, 1000)
            } else {
                alert(data.info);
                $('.fade_writ').click();
            }

        }
    });
}

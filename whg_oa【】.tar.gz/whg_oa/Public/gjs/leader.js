$(function(){
	loadRank();
})
    	
        	
//加载排名
function loadRank(){
	$.ajax({
		url: "/index.php?g=Wap&m=Poetryanswer&a=allpeo&debug=1",
		dataType: 'json',	
		success: function(data) {
			console.log(data);
			console.log(data.info);
			var html="";
			var alldata=data.info;
			for(var i=0;i<alldata.length;i++){
				var rankId=alldata[i].id;//用户id
				var rankName=alldata[i].nickname;//用户name
				var rankTime=alldata[i].time;//用时
				var rankNum=alldata[i].num;//答题数量
				var rankImg=alldata[i].headimg;//用户头像
				html+="<li><i class=\"r1\">";
				if(i==0){
					html+="<img src=\"tpl/Wap/default/valentine/img/lv1.png\"/>";
				}
				if(i==1){
					html+="<img src=\"tpl/Wap/default/valentine/img/lv2.png\"/>";
				}
				if(i==2){
					html+="<img src=\"tpl/Wap/default/valentine/img/lv3.png\"/>";
				}
				if(i>2){
					html+="<a class=\"r6\">"+(i+1)+"</a>"
				}
				html+="</i><i class=\"r2\"><img src=\""+rankImg+"\"/></i>";
				html+="<a class=\"r3\">"+rankName+"</a>";
				html+="<a class=\"r4\">"+rankTime+"</a>";
				html+="<a class=\"r5\"><em>"+rankNum+"</em>题</a></li>";
			}
			$('.rankInfo').append(html)
		}
	});	
}	
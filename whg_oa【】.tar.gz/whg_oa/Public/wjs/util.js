//docuemnt Javascript
var phonetest = /^1(3|4|5|7|8)\d{9}$/;//手机号验证正则
var emailtest = /^([\w\.\-]+)\@(\w+)(\.([\w^\_]+)){1,2}$/;//邮箱正则
var moneytest = /^(([1-9][0-9]*)|(([0]\.\d{1,2}|[1-9][0-9]*\.\d{1,2})))$/;//金额正则
var membercard = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/;//身份证
var numbertest=/^[0-9]*[1-9][0-9]*$/;
var pageSwiper;
define( ['jquery','effect','swiper','iscroll','iscroll-zoom','lcalendar','mdater','selector','ripple','tickerNews'] , function () {
   return{
     intSwiper : function(ele){
       var mySwiper = new Swiper(''+ele+'',{
             pagination : '.pagination',//页码类型
             paginationClickable:true,//页码按钮是否可以点击
             autoplay : 2000,
             mode : 'horizontal',
             loop: true,
             autoplayDisableOnInteraction: false,//不禁用autoplay
       });
     },
     pageSwiper : function(ele,dom){
       pageSwiper = new Swiper(''+ele+'',{
         speed:200,
         watchActiveIndex : true,
         onSlideChangeEnd:function(){
           var index = pageSwiper.activeIndex;
           $(''+dom+'').eq(index).trigger('click');
         }
       });
     },
     intIscroll : function(ele){
      var myscroll = new iScroll(''+ele+'',{
         hScrollbar:false,
         useTransform: false,
         vScroll:false,
         snap: true
       });
     },
     changeTimeStamp : function(data,kind){
       var newDate = new Date();
       newDate.setTime(data * 1000);
       var year = newDate.getFullYear();
       var month = newDate.getMonth()+1;
       var date = newDate.getDate();
       var hour = newDate.getHours();
       var minute = newDate.getMinutes();
       if(minute==0){ minute = "00"; }
       if(minute>0&&minute<10){ minute = '0'+minute; }
       var result1 = year + "-" + month + "-" + date + " " + hour + ":" + minute;
       var result2 = month + "-" + date + " " + hour + ":" + minute;
       var result3 = hour + ":" + minute;
       if(kind==1){ return result1; }else if(kind==2){ return result2; }else{return result3;}
    },
    getTimeStamp : function(stringTime){
      // var timestamp2 = new Date(stringTime).getTime() / 1000;
      // timestamp2 = Math.round(timestamp2);
      // return timestamp2;
      var arr = stringTime.split(/[- :]/),
          _date = new Date(arr[0], arr[1]-1, arr[2], arr[3], arr[4], arr[5]),
          timeStr = Date.parse(_date)
          return timeStr;
    },
    addTop : function(ele){
      var html = '<a href="javascript:void(0);" class="top-btn"></a>';
      $('body').append(html);
      $('.top-btn').bind('click',function(){
        $(''+ele+'').animate({scrollTop:0},200);
      })
    },
    loadTip : function(str){
      var html = '<span class="tip-span"></span>';
      var len = $('.tip-span').length;
      if(len==0){
        $('body').append(html);
        $('.tip-span').html(str).show().bounceIn();
        setTimeout(function(){$('.tip-span').remove();},2000);
      }
    },
    replaceXing : function(str,frontLen,endLen){
      var len = str.length-frontLen-endLen;
      var xing = '';
      for (var i=0;i<len;i++) {
          xing+='*';
      }
      return str.substr(0,frontLen)+xing+str.substr(str.length-endLen);
    },
    addheaderTip:function(str,kind){
      $('.tip-header').remove();
      var html='';
      html+='<div class="tip-header">';
      html+='<span class="gantan"></span>';
      html+='<span class="tip-header-text"></span>';
      if(kind==1){
        html+='<a href="/index.php/Register/index.html" class="tip-href">加入惠工<span class="tip-arrowRight"></span></a>';
      }
      html+='</div>';
      $('body').append(html);
      $('.tip-header').show().fadeInDown();
      $('.tip-header-text').html(str);

      setTimeout(function(){
        $('.tip-header').fadeOutUp();
      },3000);
    },
    showLoading : function(ele){
      var loading = '';
      loading += '<div class="loading">';
      loading += '<div class="loading-img-div">';
      loading += '<img src="/Public/wimg/loading.gif" />';
      loading += '</div><span class="loading-text">加载中，请稍后...</span>';
      loading += '</div>';
      $(''+ele+'').append(loading);
    },
    intRipple : function(){
      new Ripple({
       opacity : 0.6,  //水波纹透明度
       speed : 1,      //水波纹扩散速度
       bgColor : "#ffffff", //水波纹颜色
       cursor : false  //是否显示手型指针
     })
   },
    intLcalendar : function(ele,timeType,minDate,maxDate){
      var calendar = new LCalendar();
      calendar.init({
        'trigger': ''+ele+'',
        'type': ''+timeType+'',
        'minDate': ''+minDate+'',
        'maxDate': ''+maxDate+''
      });
    },
    intMdater : function(ele){
      $(''+ele+'').mdater({
        maxDate : null, //默认为空，日期格式
        minDate : new Date(1970, 0, 1)//默认为1970-01-01，日期格式
      });
    },
    dayOffMdater : function(ele,mindate,maxDate){
      $(''+ele+'').mdater({
        minDate : new Date(mindate), //最小日期 （日期格式：1970-01-01）
        maxDate : new Date(maxDate) //最大日期
      });
    },
    intTicker : function(ele){
      var _Ticker = $(''+ele+'').newsTicker();
    },
    intSelector : function(data,ele,title,defValue){
      $.scrEvent({
        data: data,
        evEle: ''+ele+'',
        title: title,
        defValue: defValue,
        afterAction: function (data) {
          $.each($('div.ele'),function(index){
            var text = $('div.ele').eq(index).text();
            if(text==data){
              var id = $('div.ele').eq(index).attr('data-id');
              $(''+ele+'').attr('data-id',id);
            }
          })
          $(''+ele+'').val(data);
          if(data == '年假'){
            $('#annualLeave').show();
            $('#leaveTime').css('border-bottom','1px solid #e5e5e5');
          }else{
            $('#annualLeave').hide();
            $('#leaveTime').css('border-bottom','none');
          }
        }
      });
    },
    intYm : function(data1,data2,ele,title,link,id,yy,mm){
        $.scrEvent2({
            data: data1,
            data2: data2,
            evEle: ele,
            title: '',
            defValue: yy,
            defValue2: mm,
            linkType: '.',
            afterAction: function (data1, data2) {
                $(ele).val(data1 + '-' + data2);
                var time=data1 + '-' + data2;
                window.location.href=""+link+"?id="+id+"&time="+time+"";;
            }
        });
    },
    UrlSearch : function () {
        var name,value;
        var str=location.href; //取得整个地址栏
        var num=str.indexOf("?")
        str=str.substr(num+1); //取得所有参数   stringvar.substr(start [, length ]

        var arr=str.split("&"); //各个参数放到数组里
        for(var i=0;i < arr.length;i++){
            num=arr[i].indexOf("=");
            if(num>0){
              name=arr[i].substring(0,num);
              value=arr[i].substr(num+1);
              this[name]=value;
            }
        }
    },
    accAdd : function(arg1,arg2){
      var r1,r2,m;
      try{r1=arg1.toString().split(".")[1].length}catch(e){r1=0}
      try{r2=arg2.toString().split(".")[1].length}catch(e){r2=0}
      m=Math.pow(10,Math.max(r1,r2))
      return (arg1*m+arg2*m)/m;
    },
    accSub : function(arg1, arg2) {
      var r1, r2, m, n;
      try { r1 = arg1.toString().split(".")[1].length } catch (e) { r1 = 0 }
      try { r2 = arg2.toString().split(".")[1].length } catch (e) { r2 = 0 }
      m = Math.pow(10, Math.max(r1, r2));
      //last modify by deeka
      //动态控制精度长度
      n = (r1 >= r2) ? r1 : r2;
      return ((arg1 * m - arg2 * m) / m).toFixed(n);
    },
    ajaxLoading : function(){
      var html = '<div class="loading-fade" style="display:block"><div class="change-tip"></div></div>';
      if($('.loading-fade').length == 0){
        $('body').append(html);
      }
    },
    hideLoading : function(){
      if($('.loading-fade').length > 0){
        $('.loading-fade').remove();
      }
    }
  }
})

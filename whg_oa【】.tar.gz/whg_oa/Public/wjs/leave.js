//leave.js
var uploader , imgurl = [];
define(['util','upload'], function(util,WebUploader) {
  function dateLiClick(ele){
    if($('#endTime').val() == '' && ele == 'endTime'){
      $('.day-a').removeClass('day-checked');
      $('.day-a').eq(1).addClass('day-checked');
    }
    $('.date-li,.current').click(function(){
      var dataMonth = $('.monthtag').attr('data-month');
      var dataDay = $(this).attr('data-day');
      var dayVal = $('.day-checked').attr('data-val');
      var dayText = $('.day-checked').text();
      if(dataMonth>0&&dataMonth<10){ dataMonth = '0'+dataMonth; }
      if(dataDay>0&&dataDay<10){ dataDay = '0'+dataDay; }
      var dateVal = $('.yeartag').attr('data-year') + '-' + dataMonth + '-' + dataDay + ' ' + dayText;
      $('#'+ele+'').val(dateVal);
      $('#'+ele+'').attr('data-day',dayVal);
      if($('#startTime').val()!='' && $('#endTime').val()!=''){
        setTimeout(function(){
          isRight($('#startTime').val() , $('#endTime').val())
        },100);
      }
    })
    $('.day-a').click(function(){
      var checkedVal = $(this).attr('data-val');
      var checkedText = $(this).text();
      var dataMonth = $('.monthtag').attr('data-month');
      var dataDay = $('.current').attr('data-day');
      if($('li.current').length == 0){
        util.loadTip('请先选择一个日期');
      }else{
        $('.day-a').removeClass('day-checked');
        $(this).addClass('day-checked');
        if(dataMonth>0&&dataMonth<10){ dataMonth = '0'+dataMonth; }
        if(dataDay>0&&dataDay<10){ dataDay = '0'+dataDay; }
        var dateVal = $('.yeartag').attr('data-year') + '-' + dataMonth + '-' + dataDay + ' ' + checkedText;
        $('#'+ele+'').val(dateVal);
        $('#'+ele+'').attr('data-day',checkedVal);
        if($('#startTime').val()!='' && $('#endTime').val()!=''){
          setTimeout(function(){
            isRight($('#startTime').val() , $('#endTime').val())
          },100);
        }
      }
    })
  }

  function isRight(startTime,endTime){
    var newStartTime = startTime.split(' ');
    var newEndTime = endTime.split(' ');
    var strStartTime , strEndTime , starttimetype , endtimetype;
    if(newStartTime[1] == "上午"){
      strStartTime = newStartTime[0] + ' 08:0:0';
      starttimetype = 1;
    }else{
      strStartTime = newStartTime[0] + ' 14:0:0';
      starttimetype = 2;
    }
    if(newEndTime[1] == "上午"){
      strEndTime =  newEndTime[0] + ' 08:0:0';
      endtimetype = 1;
    }else{
      strEndTime =  newEndTime[0] + ' 14:0:0';
      endtimetype = 2;
    }

    var startTimeStamp = util.getTimeStamp(strStartTime);
    var newEndTimeStamp = util.getTimeStamp(strEndTime);
    //console.log('开始时间戳：' + startTimeStamp + ',结束时间戳：' + newEndTimeStamp);
    if(newEndTimeStamp < startTimeStamp){
      util.loadTip('结束时间必须大于开始时间');
      $('#startTime').attr('data-state','false');
    }else{
      $('#startTime').attr('data-state','true');
      calcumDays(newStartTime[0],newEndTime[0],starttimetype,endtimetype)
    }
  }
  //计算请假时长
  function calcumDays(startdate,enddate,starttimetype,endtimetype){
    //console.log(startdate + ' '+ enddate + ' ' + starttimetype + ' ' + endtimetype);
    util.ajaxLoading();
     $.ajax({
         url:ajax_getdays,
         type:'POST',
         dataType:'json',
         data:{
           startdate:startdate,
           enddate:enddate,
           starttimetype:starttimetype,
           endtimetype:endtimetype
         },
         success:function(data){
           util.hideLoading();
           if(data.status==1){
             var kind = $('#leaveOften').attr('data-kind');
             var dayNum = data.info;
             if(kind=="dayoff"){
               dayNum = Number(dayNum) * 8;
               $('#leaveOften').html(dayNum + '小时');
             }else{
               $('#leaveOften').html(dayNum + '天');
             }
           }
         }
     })
  }
  //提交表单(请假)
  function subLeaveInfo(){
    var leavetype = $('#leaveKind').attr('data-id');
    var startDate = $('#startTime').val().split(' ');
    var endDate = $('#endTime').val().split(' ');
    var startTime = startDate[0];
    var endTime = endDate[0];
    var starttimetype , endtimetype;
    if(startDate[1] == "上午"){ starttimetype = 1; }else{ starttimetype = 2; }
    if(endDate[1] == "上午"){ endtimetype = 1; }else{ endtimetype = 2; }
    var leaveremark = $('.leave-textarea').val();
    var auditoruserid = [] , copyuserid = [];

    for(var i=0;i<$('.approver-item').length;i++){
      var id = $('.add-item').eq(i).attr('data-userid');
      auditoruserid.push(id);
    }
    for(var j=0;j<$('.chao-item').length;j++){
      var id = $('.chao-item').eq(j).attr('data-userid');
       copyuserid.push(id);
    }
    if(leavetype=="" || $('#startTime').val()=="" || $('#endTime').val()=="" || auditoruserid.length==0){
      util.loadTip('请选择所有带*号的内容');
      return;
    }
    if(auditoruserid.length < $('.add-item').length){
      util.loadTip('请选择所有的审批人');
      return;
    }
    if($('#startTime').attr('data-state') == "false"){
      util.loadTip('结束时间必须大于开始时间');
      return;
    }
    if(leavetype==2){
      var yearSurplus = $('#yearSurplus').text();
      var dayNum = $('#leaveOften').text();
      dayNum =  Number(dayNum.substr(0,1));
      yearSurplus = Number(yearSurplus.substr(0,1));
      if(dayNum > yearSurplus){
        util.loadTip('年假天数不足，请调整请假时间');
        return;
      }
    }
    $('.sub-btn').html('提交中...').attr('disabled', true);
    $.ajax({
         url:ajax_makeLeave,
         type:'POST',
         dataType:'json',
         data:{
           leavetype:leavetype,
           startdate:startTime,
           starttimetype:starttimetype,
           enddate:endTime,
           endtimetype:endtimetype,
           auditoruserid:auditoruserid,
           copyuserid:copyuserid,
           leaveremark:leaveremark,
           img:imgurl
         },
         success:function(data){
           if(data.status==1){
             util.loadTip('提交成功');
             window.location.href=data.url;
           }else{
             util.loadTip(data.info);
             $('.sub-btn').html('提交').attr('disabled', false);
           }
         }
    })
  }
  //活动申报提交数据
  function upInfo() {
      var files = [];
      var title = $('#act1').val();
      var spend = $('#act2').val();
      var account = $('#act3').val();
      var auditoruserid = [],copyuserid = [];
      $.each($('.upFiles li'), function(index) {
          var id = $('.upFiles li').eq(index).attr('data-id');
          files.push(id);
      });

      for (var i = 0; i < $('.approver-item').length; i++) {
          var id = $('.add-item').eq(i).attr('data-userid');
          auditoruserid.push(id);
      }
      for (var j = 0; j < $('.chao-item').length; j++) {
          var id = $('.chao-item').eq(j).attr('data-userid');
          copyuserid.push(id);
      }
      if (title == "") {
        util.loadTip('请填写活动标题');
        return;
      }
      if (spend == "") {
        util.loadTip('请填写活动预算');
        return;
      }
      if (!(moneytest.test(spend))) {
          util.loadTip('请输入正确的活动金额');
          return;
      }
      if (auditoruserid.length < $('.add-item').length) {
          util.loadTip('请选择所有的审批人');
          return;
      }
      $('.sub-btn').html('提交中...').attr('disabled', true);
      $.ajax({
          url: ajax_makeApply,
          dataType: 'json',
          type: 'POST',
          data: {
              title: title,
              money: spend,
              remark: account,
              file: files,
              auditoruserid: auditoruserid,
              copyuserid: copyuserid
          },
          success: function(data) {
            if (data.status == 1) {
              util.loadTip('提交成功');
              window.location.href = data.url;
            } else {
              util.loadTip(data.info);
              $('.sub-btn').html('提交').attr('disabled', false);
            }
          }
      }); //ajax
  }
  //提交数据(加班申请)
  function overtimeSub(){
    var startTime = $('#startTime').val();
    var overtime = $('#overtime').val();
    var overtimeReason = $('#overtimeReason').val();
    var auditoruserid = [] , copyuserid = [];
    for (var i = 0; i < $('.approver-item').length; i++) {
       var id = $('.add-item').eq(i).attr('data-userid');
       auditoruserid.push(id);
    }
    for (var j = 0; j < $('.chao-item').length; j++) {
       var id = $('.chao-item').eq(j).attr('data-userid');
       copyuserid.push(id);
    }
    if(startTime==""||overtime==""){
       util.loadTip('请填写所有带有*号的选项');
    }
    if (auditoruserid.length < $('.add-item').length) {
       util.loadTip('请选择所有的审批人');
       return;
    }
    overtime = overtime.substring(0,overtime.length-2);
    $('.sub-btn').html('提交中...').attr('disabled', true);
    $.ajax({
        url: ajax_makeApply,
        dataType: 'json',
        type: 'POST',
        data: {
            starttime: startTime,
            worktime: overtime,
            overtimerea: overtimeReason,
            image: imgurl,
            auditoruserid: auditoruserid,
            copyuserid: copyuserid
        },
        success: function(data) {
          if (data.status == 1) {
            util.loadTip('提交成功');
            window.location.href = data.url;
          } else {
            util.loadTip(data.info);
            $('.sub-btn').html('提交').attr('disabled', false);
          }
        }
    }); //ajax
  }
  //提交数据(调休申请)
  function dayoffSub(){
    var kind = $('.dayoff-checked').attr('data-val');
    var startDate = $('#startTime').val().split(' ');
    var endDate = $('#endTime').val().split(' ');
    var startTime = startDate[0];
    var endTime = endDate[0];
    var starttimetype , endtimetype;
    if(startDate[1] == "上午"){ starttimetype = 1; }else{ starttimetype = 2; }
    if(endDate[1] == "上午"){ endtimetype = 1; }else{ endtimetype = 2; }
    var leaveremark = $('.leave-textarea').val();
    var dayHour = $('#leaveOften').text();
    var daySurplus = $('.dayoff-item[data-state="true"]').find('span').text();
    dayHour = dayHour.substring(0,dayHour.length-2);
    daySurplus = daySurplus.substring(0,daySurplus.length-2);
    var auditoruserid = [] , copyuserid = [];

    for(var i=0;i<$('.approver-item').length;i++){
      var id = $('.add-item').eq(i).attr('data-userid');
      auditoruserid.push(id);
    }
    for(var j=0;j<$('.chao-item').length;j++){
      var id = $('.chao-item').eq(j).attr('data-userid');
      copyuserid.push(id);
    }
    if($('#startTime').val()=="" || $('#endTime').val()=="" || auditoruserid.length==0){
      util.loadTip('请选择所有带*号的内容');
      return;
    }
    if(auditoruserid.length < $('.add-item').length){
      util.loadTip('请选择所有的审批人');
      return;
    }
    if($('#startTime').attr('data-state') == "false"){
      util.loadTip('结束时间必须大于开始时间');
      return;
    }
    if(Number(dayHour) > Number(daySurplus)){
      util.loadTip('剩余调休工时不足，请调整时间');
      return;
    }
    $('.sub-btn').html('提交中...').attr('disabled', true);
    $.ajax({
         url:ajax_makeApply,
         type:'POST',
         dataType:'json',
         data:{
           leavetype:kind,
           startdate:startTime,
           starttimetype:starttimetype,
           enddate:endTime,
           endtimetype:endtimetype,
           auditoruserid:auditoruserid,
           copyuserid:copyuserid,
           leaveremark:leaveremark,
           image:imgurl
         },
         success:function(data){
           if(data.status==1){
             util.loadTip('提交成功');
             window.location.href=data.url;
           }else{
             util.loadTip(data.info);
             $('.sub-btn').html('提交').attr('disabled', false);
           }
         }
    })
  }
  //实例化上传图片组件
  function intUploader(){
    uploader = WebUploader.create({
        // 文件接收服务端。
        server: uploadfile,
        // swf文件路径
        swf: 'http://cdn.staticfile.org/webuploader/0.1.0/Uploader.swf',
        // 选择文件的按钮。可选。
        // 内部根据当前运行是创建，可能是input元素，也可能是flash.
        pick: '.upload-btn',
        //队列中只允许存在一个文件
        fileNumLimit: 6,
        // 选完文件后，是否自动上传。
        auto: true,
        // 不压缩image, 默认如果是jpeg，文件上传前会压缩一把再上传！
        resize: true,
        duplicate: true,
        accept: {
         title: 'Images',
         extensions: 'jpg,jpeg,bmp,png',
         mimeTypes: 'image/jpg,image/jpeg,image/png'
       },
       thumbnailWidth:'1.25rem',
       thumbnailHeight:'1.25rem'
    })
    uploader.on( 'fileQueued', function( file ) {
      // $list为容器jQuery实例
      var $img = $('<div class="img-item" id="'+file.id+'"><img class="upload-img"/><a href="javascript:void(0);" class="del-img"></a></div>');
      var $img_len = $('.upload-img').length;
      //图片数量小于6张时才添加预览容器，当图片数量为5时将上传按钮隐藏
      if($img_len < 6){ $('.upload-img-box').append( $img ); }
      if($img_len == 5){ $('.upload-btn').hide(); }
      // 创建缩略图，如果为非图片文件，可以不用调用此方法。
      uploader.makeThumb( file, function( error, src ) {
        if ( error ) {
          $img.replaceWith('<span>不能预览</span>');
          return;
        }
        $img.find('.upload-img').attr( 'src', src );
      }, uploader.thumbnailWidth, uploader.thumbnailHeight );
      util.ajaxLoading();
      $('.del-img').unbind('click').bind('click',function(){
        var id = $(this).closest('.img-item').attr('id');
        var dis = $('.upload-btn').css('display');
        $.each($('.img-item'),function(index){
          var itemId = $('.img-item').eq(index).attr('id');
          if(id==itemId){
            $('.img-item').eq(index).remove();
            uploader.removeFile( id, true );
            imgurl.splice(index,1);
          }
        })
        if(dis=='none'){ $('.upload-btn').show(); }
      })
    });
    uploader.on( 'uploadSuccess', function( file , response ) {
      if(response.status == 1){
        imgurl.push(response.info);
      }else{
        util.loadTip(response.info);
      }
      util.hideLoading();
      //console.log(imgurl);
    });
    uploader.on( 'error', function( type ) {
       if(type == "Q_EXCEED_NUM_LIMIT"){
         util.loadTip('图片数量不得超过6张');
       }else{
         util.loadTip("上传出错！错误代码"+type);
       }
      util.hideLoading();
    });
  }
  return{
    "dateLiClick":dateLiClick,
    "intUploader":intUploader,
    "subLeaveInfo":subLeaveInfo,
    "upInfo":upInfo,
    "overtimeSub":overtimeSub,
    "dayoffSub":dayoffSub
  }
})

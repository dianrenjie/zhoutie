require.config({
        baseUrl: '/Public/lib',
        paths: {
            'jquery': 'jquery',
            'upload':'webuploader.min',
            'require-css': 'require-css',
            'swiper': 'swiper-3.3.1.min',
            'flexible': 'flexible',
            'fastclick': 'fastclick',
            'anime':'anime.min',
            'iscroll': 'iscroll',
            'iscroll-zoom': 'iscroll-zoom',
            'lcalendar':'LCalendar.min',
            'mdater':'mdater',
            'selector':'jquery.selector',
            'ripple':'ripple.min',
            'fly':'fly',
            'tickerNews':'jquery.tickerNews.min',
            'effect': '../wjs/effect',
            'util': '../wjs/util'
        },
        shim: {
            'iscroll': {
                'deps': ['require-css!../wcss/iscroll.css']
            },
            'iscroll-zoom': {
                'deps': ['require-css!../wcss/iscroll.css']
            },
            'lcalendar':{
                'deps': ['require-css!../wcss/LCalendar.css']
            },
            'fly':{ 'deps': ['jquery'] },
            'tickerNews':{ 'deps': ['jquery'] },
            'mdater':{ 'deps': ['jquery'] },
            'selector':{ 'deps': ['jquery'] },
            'effect':{ 'deps': ['jquery','fly'] },
            'upload':{ 'deps': ['jquery'] }
        }
    })
    /*所有页面渲染时需要加载的模块*/
    require(['fastclick'], function(Fastclick) {
      Fastclick.attach(document.body);
    })

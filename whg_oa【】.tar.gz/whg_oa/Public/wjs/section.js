/**
 * Created by jy on 2017/6/20.
 */
 define(['util'], function(util) {
    // var list=[//0:出勤 1:休假 2:加班 3:迟到 4:早退
    // {id:'0',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'出勤',workstatus:'早退,下班打卡不在正常范围内',state:0},
    // {id:'1',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'休假',workstatus:'迟到497分钟,上班打卡不在正常范围内',state:1},
    // {id:'2',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'加班',workstatus:'早退,下班打卡不在正常范围内',state:2},
    // {id:'3',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'迟到',workstatus:'早退,下班打卡不在正常范围内',state:3},
    // {id:'4',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'早退',workstatus:'早退,下班打卡不在正常范围内',state:4},
    // {id:'5',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'缺勤',workstatus:'迟到320分钟',state:5},
    // {id:'6',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'出勤',workstatus:'迟到122分钟',state:3},
    // {id:'7',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'加班',workstatus:'事假全天,病假全天',state:2},
    // {id:'8',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'缺勤',workstatus:'事假全天',state:1},
    // {id:'9',img:'http://www.qqjay.com/uploads/allimg/160306/1_0PP4Q19.jpg',name:'xxx',section:'迟到',workstatus:'正常',state:0},
    // ];
    function clicks(){
        $('.date-li,.current').click(function(){
            var section=$('#section em').attr('data-val');
            var dataMonth = $('.monthtag').attr('data-month');
            var dataDay = $(this).attr('data-day');
            var dayVal = $('.day-checked').attr('data-val');
            var dayText = $('.day-checked').text();
            if(dataMonth>0&&dataMonth<10){ dataMonth = '0'+dataMonth; }
            if(dataDay>0&&dataDay<10){ dataDay = '0'+dataDay; }
            var dateVal = $('.yeartag').attr('data-year') + '-' + dataMonth + '-' + dataDay ;
            $('#date').val(dateVal);
            $('#date').attr('data-day',dayVal);
            Timed=$('.yeartag').attr('data-year') + '-' + dataMonth;
            loadInfo(section,dateVal,link,Timed);
        });
    }
    function getNowTime(link){
        var afterMonth = new Date().getMonth() + 1;
        var afterDay = new Date().getDate();
        if(afterMonth>0&&afterMonth<10){ afterMonth = '0'+afterMonth; }
        if(afterDay>0&&afterDay<10){ afterDay = '0'+afterDay; }
        var dateResult = new Date().getFullYear() + '-' +afterMonth+ '-' + afterDay;
        $('#date').val(dateResult);
        var ym2 = new Date();
        var y2=ym2.getFullYear();
        var m2=ym2.getMonth() + 1;
        var times=y2+'-'+m2;
        Timed=times;

        loadInfo(1,dateResult,link,times);
    }

    function loadInfo(section,date,link,time){
        $.ajax({
            url: superviseajax,
            dataType: 'json',
            type:'POST',
            data:{section:section,date:date},
            success: function(data) {
                var list=data.info;
                console.log(list);
                if(data.status==1){
                    var links=link.toString();
                    var html="";
                    if(list.length==0){
                        $('.list').hide();
                        $('.emptys').show();
                    }else{
                        for(var i=0;i<list.length;i++){
                            html+="<li data-id=\""+list[i].userid+"\" onclick=\"goPage(this,'"+link+"')\">";
                            html+="<img src=\""+list[i].img+"\"/>";
                            html+="<span>"+list[i].name+"</span>";
                            html+="<p>"+list[i].workstatus+"</p>";
                            html+="<a data-color=\""+list[i].state+"\">"+list[i].section+"</a>";
                            html+="</li>";
                        }
                        $('.list').html(html);
                        $('.list').show();
                        $('.emptys').hide();          
                    }
                }
                else{
                    util.loadTip('请求失败！');
                }
            }
        });//ajax




}



function GetRequest() {
        var url = location.search; //获取url中"?"符后的字串
        var theRequest = new Object();
        if (url.indexOf("?") != -1) {
            var str = url.substr(1);
            strs = str.split("&");
            for(var i = 0; i < strs.length; i ++) {
                theRequest[strs[i].split("=")[0]]=unescape(strs[i].split("=")[1]);
            }
        }
        return theRequest;
    }

    return{
        'loadInfo':loadInfo,
        'getNowTime':getNowTime,
        'GetRequest':GetRequest,
        "clicks":clicks
    }
})
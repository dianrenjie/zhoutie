//attendance.js
define(['util'], function(util) {
    //获取当前打卡的状态
    function getClockState() {
        var afterMonth = new Date().getMonth() + 1;
        var afterDay = new Date().getDate();
        if (afterMonth > 0 && afterMonth < 10) { afterMonth = '0' + afterMonth; }
        if (afterDay > 0 && afterDay < 10) { afterDay = '0' + afterDay; }
        $('#timeInput').val(new Date().getFullYear() + '-' + afterMonth + '-' + afterDay);
        nowDateTime = new Date().getFullYear() + '-' + afterMonth + '-' + afterDay;
        if (clockState == 1) {
            $('#morning').addClass('can-click');
            $('.attendance-btn-text').html('上班打卡');
            $('.attendance-btn').hide();
            $('.default').css('display', 'inline-block');
            getLocations();
            getClockInfo();
        } else if (clockState == 2) {
            $('#morning,#afternoon').addClass('can-click');
            $('.attendance-btn-text').html('下班打卡');
            $('.attendance-btn').hide();
            $('.default').css('display', 'inline-block');
            getLocations();
            getClockInfo();
        } else {
            $('#morning,#afternoon').addClass('can-click');
            $('.attendance-btn').hide();
            $('.complete').css('display', 'inline-block');
            $('.location-section').hide();
            getClockInfo();
        }
    }
    //查询打卡情况
    function getClockInfo(type) {
        var clockDate = $('#timeInput').val();
        $.ajax({
            url: ajax_getDaysInfo,
            type: 'POST',
            dataType: 'json',
            data: { date: clockDate },
            success: function(res) {
                var needtoWorkTime = res.needtoWorkTime;
                var needoffWorkTime = res.needoffWorkTime;
                var toworkstatus = res.toworkstatus;
                var offworkstatus = res.offworkstatus;
                var toremark = res.toremark;
                var offremark = res.offremark;
                //console.log(res);
                if (res.toworktime != "") {
                    var toworktime = util.changeTimeStamp(res.toworktime, 3);
                    $('#morning').find('.clockTime').html(toworktime);
                    if (toworkstatus.length == 0) {
                        $('#morning .clock-state').show().append('<span class="state-lable">正常</span>');
                    } else {
                        var html = '';
                        for (var i = 0; i < toworkstatus.length; i++) {
                            var toworkstatusText = toworkstatus[i];
                            html += '<span class="state-lable abnormal">' + toworkstatusText + '</span>';
                        }
                        $('#morning .clock-state').show();
                        $('#morning .clock-state').append(html);
                        $('#morning .clock-state').find('.report').show();
                    }
                }
                if (res.offworktime != "") {
                    var offworktime = util.changeTimeStamp(res.offworktime, 3);
                    $('#afternoon').find('.clockTime').html(offworktime);
                    if (offworkstatus.length == 0) {
                        $('#afternoon .clock-state').show().append('<span class="state-lable">正常</span>');
                    } else {
                        var html = '';
                        for (var i = 0; i < offworkstatus.length; i++) {
                            var offworkstatusText = offworkstatus[i];
                            html += '<span class="state-lable abnormal">' + offworkstatusText + '</span>';
                        }
                        $('#afternoon .clock-state').show();
                        $('#afternoon .clock-state').append(html);
                        $('#afternoon .clock-state').find('.report').show();
                    }
                }
                $('#morning').attr('data-remark', toremark);
                $('#afternoon').attr('data-remark', offremark);
                $('#morning-span').html(needtoWorkTime);
                $('#afternoon-span').html(needoffWorkTime);
            }
        })
}

function historyInfo(date) {
    $.ajax({
        url: ajax_getDaysInfo,
        type: 'POST',
        dataType: 'json',
        data: { date: date },
        success: function(res) {
            var needtoWorkTime = res.needtoWorkTime;
            var needoffWorkTime = res.needoffWorkTime;
            var toworkstatus = res.toworkstatus;
            var offworkstatus = res.offworkstatus;
            var toremark = res.toremark;
            var offremark = res.offremark;
                //console.log(res);
                if (res.toworktime == "") {
                    $('#historyM').removeClass('can-click');
                    $('#historyM .clockTime').html('');
                    $('#historyM .clock-state').hide();
                }
                if (res.toworktime != "") {
                    var toworktime = util.changeTimeStamp(res.toworktime, 3);
                    $('#historyM').addClass('can-click');
                    $('#historyM').find('.clockTime').html(toworktime);
                    $('#historyM .clock-state').find('.state-lable').remove();
                    if (toworkstatus.length == 0) {
                        $('#historyM .clock-state').show().append('<span class="state-lable">正常</span>');
                    } else {
                        var html = '';
                        for (var i = 0; i < toworkstatus.length; i++) {
                            var toworkstatusText = toworkstatus[i];
                            html += '<span class="state-lable abnormal">' + toworkstatusText + '</span>';
                        }
                        $('#historyM .clock-state').show();
                        $('#historyM .clock-state').append(html);
                        $('#historyM .clock-state').find('.report').show();
                    }
                }
                if (res.offworktime == "") {
                    $('#historyA').removeClass('can-click');
                    $('#historyA .clockTime').html('');
                    $('#historyA .clock-state').hide();
                }
                if (res.offworktime != "") {
                    var offworktime = util.changeTimeStamp(res.offworktime, 3);
                    $('#historyA').addClass('can-click');
                    $('#historyA').find('.clockTime').html(offworktime);
                    $('#historyA .clock-state').find('.state-lable').remove();
                    if (offworkstatus.length == 0) {
                        $('#historyA .clock-state').show().append('<span class="state-lable">正常</span>');
                    } else {
                        var html = '';
                        for (var i = 0; i < offworkstatus.length; i++) {
                            var toworkstatusText = toworkstatus[i];
                            html += '<span class="state-lable abnormal">' + toworkstatusText + '</span>';
                        }
                        $('#historyA .clock-state').show();
                        $('#historyA .clock-state').append(html);
                        $('#historyA .clock-state').find('.report').show();
                    }
                }
                $('#historyM').attr('data-remark', toremark);
                $('#historyA').attr('data-remark', offremark);
                $('#historyM-span').html(needtoWorkTime);
                $('#historyA-span').html(needoffWorkTime);
            }
        })
}

    //调用jssdk获取用户地理位置
    function getLocations() {
      var tip = setTimeout(function(){
        util.loadTip('若长时间获取不到定位，请刷新页面');
      },5000);
        wx.ready(function() {
            wx.getLocation({
                type: 'gcj02', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
                success: function(res) {
                    clearTimeout(tip);
                    var latitude = res.latitude; // 纬度，浮点数，范围为90 ~ -90
                    var longitude = res.longitude; // 经度，浮点数，范围为180 ~ -180。
                    var speed = res.speed; // 速度，以米/每秒计
                    var accuracy = res.accuracy; // 位置精度
                    $('.location-section').attr('data-latitude', latitude);
                    $('.location-section').attr('data-longitude', longitude);
                    $.ajax({
                        url: ajax_localtion,
                        type: 'POST',
                        dataType: 'json',
                        data: { latitude: latitude, longitude: longitude },
                        success: function(res) {
                            var inRange = res.inRange;
                            var address = res.address;
                            showLocateInformation(inRange, address);
                        }
                    })
                },
                fail: function(res) {
                    $('.attendance-tip-box').hide();
                    $('#noAction').show();
                    $('.tipfade').fadeIn();
                }
            });
        });
      }
    //显示定位信息
    function showLocateInformation(kind, addressText) {
        switch (kind) {
            case 0:
            $('.position-icon').attr('src', '/Public/wimg/postion2.png').removeClass('animate-bounce-down');
            $('.location-state').removeClass('in-area').addClass('no-area');
            $('.refresh-a').show();
            $('.location-state span').html('不在考勤范围内');
            $('.location-area').show().html(addressText);
            $('.default').attr('data-state', 'true');
            break;
            case 1:
            $('.position-icon').attr('src', '/Public/wimg/postion1.png').removeClass('animate-bounce-down');
            $('.location-state').removeClass('no-area').addClass('in-area');
            $('.refresh-a').hide();
            $('.location-state span').html('已进入考勤范围');
            $('.location-area').show().text(addressText);
            $('.default').attr('data-state', 'true');
            break;
            default:
            $('.position-icon').attr('src', '/Public/wimg/postion2.png').removeClass('animate-bounce-down');
            $('.location-state').removeClass('no-area').addClass('no-area');
            $('.refresh-a').show();
            $('.location-state span').html('获取位置出现错误');
            $('.location-area').show().text(addressText);
            $('.default').attr('data-state', 'true');
            break;
        }
    }
    //重新获取定位信息
    function refreshLocation() {
        $('.position-icon').attr('src', '/Public/wimg/postion.png').addClass('animate-bounce-down');
        $('.location-state').removeClass('no-area in-area');
        $('.location-state span').html('定位中');
        $('.location-area,.refresh-a').hide();
        getLocations();
    }
    //获取当前时间（时+分）
    function getNowTime() {
        var now = new Date();
        var hours = now.getHours();
        var minutes = now.getMinutes();
        if (minutes == 0) { minutes = "00"; }
        if (hours > 0 && hours < 10) { hours = '0' + hours; }
        if (minutes > 0 && minutes < 10) { minutes = '0' + minutes; }
        $('#nowHour,#earlyHours').html(hours);
        $('#nowMinute,#earlyMintues').html(minutes);
    }
    //为日历中的date-li元素绑定查询打卡记录事件
    function dateLiClick() {
        $('.date-li').click(function() {
            var dataMonth = $('.monthtag').attr('data-month');
            var dataDay = $(this).attr('data-day');
            if (dataMonth > 0 && dataMonth < 10) { dataMonth = '0' + dataMonth; }
            if (dataDay > 0 && dataDay < 10) { dataDay = '0' + dataDay; }
            var dateVal = $('.yeartag').attr('data-year') + '-' + dataMonth + '-' + dataDay;
            if (dateVal != nowDateTime) {
                $('.attendance-btn-box,#now,.location-section').hide();
                $('#history').show();
                historyInfo(dateVal);
            } else {
                if (clockState != 3) {
                    $('.attendance-btn-box,#now,.location-section').show();
                } else {
                    $('.attendance-btn-box,#now').show();
                }
                $('#history').hide();
            }
        })
    }
    //绑定打卡事件
    function startClock() {
        var locationState = $('.location-state').hasClass('in-area');
        var earlyFlag = isEearly();
        if (clockState == 1 && locationState == false) {
            $('.attendance-tip-box').hide();
            $('#outRange').show();
            $('.tipfade').fadeIn();
            return;
        }
        if (clockState == 2 && earlyFlag == false) {
            $('.attendance-tip-box').hide();
            $('#early').show();
            $('.tipfade').fadeIn();
            return;
        }
        if (clockState == 2 && earlyFlag == true) {
            if (locationState == false) {
                $('.attendance-tip-box').hide();
                $('#outRange').show();
                $('.tipfade').fadeIn();
                return;
            }
        }
        clocked();
    }
    //确认打卡
    function clocked() {
        var latitude = $('.location-section').attr('data-latitude');
        var longitude = $('.location-section').attr('data-longitude');
        $.ajax({
            url: ajax_clockedIn,
            type: 'POST',
            dataType: 'json',
            data: { latitude: latitude, longitude: longitude, type: clockState },
            success: function(data) {
                if (data.errornum > 0) {
                    var html = '';
                    var abnormalData = data.error;
                    for (var i = 0; i < abnormalData.length; i++) {
                        var abnormalText = abnormalData[i];
                        html += '<span class="state-lable abnormal">' + abnormalText + '</span>';
                    }
                    if (clockState == 1) {
                        $('#morning .clock-state').show();
                        $('#morning .clock-state').append(html);
                        $('#morning .clock-state').find('.report').show();
                        $('#morning .clockTime').html(data.time);
                    } else {
                        $('#afternoon .clock-state').show();
                        $('#afternoon .clock-state').append(html);
                        $('#afternoon .clock-state').find('.report').show();
                        $('#afternoon .clockTime').html(data.time);
                    }
                } else if (data.errornum == 0) {
                    if (clockState == 1) {
                        $('#morning .clock-state').show().append('<span class="state-lable">正常</span>');
                        $('#morning .clockTime').html(data.time);
                    } else {
                        $('#afternoon .clock-state').show().append('<span class="state-lable">正常</span>');
                        $('#afternoon .clockTime').html(data.time);
                    }
                }
                $('.default').hide();
                $('.success').css('display', 'inline-block');
                $('.gou').bounceIn();
                $('.location-section').hide();
            }
        })
}
    //判断是否早退（下班打卡）
    function isEearly() {
        var nowH = Number($('#nowHour').html());
        var nowM = Number($('#nowMinute').html());
        var offWorkTime = $('#afternoon-span').html().split(':');
        var offWorkTimeH = Number(offWorkTime[0]);
        var offWorkTimeM = Number(offWorkTime[1]);
        var flag = true;
        if (nowH < offWorkTimeH) {
            flag = false;
        } else if (nowH == offWorkTimeH) {
            if (nowM < offWorkTimeM) {
                flag = false;
            }
        }
        return flag;
    }

    return {
        "getClockState": getClockState,
        "getLocations": getLocations,
        "showLocateInformation": showLocateInformation,
        "refreshLocation": refreshLocation,
        "getNowTime": getNowTime,
        "clocked": clocked,
        "dateLiClick": dateLiClick,
        "startClock": startClock
    }
})

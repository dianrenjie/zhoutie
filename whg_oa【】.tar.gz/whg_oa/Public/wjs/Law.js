define(['jquery', 'util'], function($, util) {
    return {
        loadLecture: function() {
            $.ajax({
                url: loadLectureUrl,
                dataType: 'json',
                type: 'POST',
                data: { articleNo: lectureNo, type: 4 },
                success: function(data) {
                    var lectureData = data.info;
                    if (lectureData.length > 0 || lectureData != "") {
                        var html = "";
                        for (var i = 0; i < lectureData.length; i++) {
                            var articleId = lectureData[i].id; //文章的id
                            var articleImg = lectureData[i].imageurl; //文章的图片路径
                            var articleTitle = lectureData[i].title; //文章的图片路径
                            var articlTime = util.changeTimeStamp(lectureData[i].addtime, 2); //文章的发布时间
                            var articleFrom = lectureData[i].source; //文章的来源

                            html += "<li class=\"article-li\">";
                            html += "<a class=\"todetail\" href=\"" + articlDetailUrl + "?id=" + articleId + "\">";
                            html += "<img src=\"" + articleImg + "\" class=\"article-pic\" />";
                            html += "<p class=\"article-p article-title\">" + articleTitle + "</p>";
                            html += "<p class=\"article-p\">" + articlTime + "</p>";
                            html += "<p class=\"article-p\">" + articleFrom + "</p>";
                            html += "</a>";
                            html += "</li>";
                            lectureNo++;
                        }
                        $('.lecture').append(html);
                    } else {
                        if (lectureNo == 0) {
                            var noneHtml = "";
                            noneHtml += "<div class=\"article-none\">";
                            noneHtml += "<img src=\"/Public/wimg/barimage.bmp\" class=\"noneTip-img\"/>";
                            noneHtml += "<p class=\"noneTip-p\">暂时没有文章！</p></div>";
                            $('.lecture').html(noneHtml);
                        } else {
                            $('.lecture').append('<div class="loading">没有更多内容了！</div>');
                            $('.lecture').off('scroll');
                        }
                    }
                }
            })
        }
    }
})

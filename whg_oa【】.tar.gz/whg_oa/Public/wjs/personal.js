//register.js
var codeTime = 60; //验证码间隔发送时间（秒）
define(['jquery', 'util'], function($, util) {
    return {
        getCode: function() {
            var memberCard = $.trim($('#memberCard').val());
            var phone = $.trim($('#memberPhone').val());
            var security = $.trim($('#security').val());
            var state = $('.personal-code').attr('data-state');
            var name=$.trim($('#memberName').val());
            if(state=="true"){
              if (memberCard == "" || phone == ""||name=="") {
                util.loadTip('请填写姓名、身份证和手机');
                return;
            }
            if (!(membercard.test(memberCard))) {
                util.loadTip('请输入正确的身份证号');
                return;
            }
            if (!(phonetest.test(phone))) {
                util.loadTip('请输入正确的手机号');
                return;
            }
            $.ajax({
                url:yanzhengurl,
                dataType: 'json',
                type: 'POST',
                data: { telephone: phone },
                success: function(data) {
                  if (data.state == 1) {
                    util.loadTip('验证码已发送,请注意查收');
                    if (state == "true") {
                      for (var i = 1; i <= codeTime; i++) {
                        setTimeout("update_time(" + i + "," + codeTime + ")", i * 1000);
                    }
                }
            } else {
                util.loadTip(data.info);
            }
        }
    })
        }
    },
    submit: function() {
        var memberCard = $.trim($('#memberCard').val());
        var phone = $.trim($('#memberPhone').val());
        var security = $.trim($('#security').val());
        var code = $.trim($('#memberCode').val());
        var name=$.trim($('#memberName').val());
        if (memberCard == "" || phone == ""||name=="") {
            util.loadTip('请填写姓名、身份证和手机');
            return;
        }
        if (!(membercard.test(memberCard))) {
            util.loadTip('请输入正确的身份证号');
            return;
        }
        if (!(phonetest.test(phone))) {
            util.loadTip('请输入正确的手机号');
            return;
        }
        if(code==""){
          util.loadTip('请输入验证码');
          return;
      }
      $('.reg-btn').html('提交中...').attr('disabled', true);
      $.ajax({
        url: personalurl,
        type: 'POST',
        dataType: 'json',
        data: {idcard: memberCard,phone: phone,code: code,security:security,name:name},
        success: function(data) {
                    //注册失败
                    if (data.status == 0) {
                        util.loadTip(data.info);
                        $('.reg-btn').html('提交申请').attr('disabled', false);
                    } else {
                        util.loadTip(data.info);
                        setTimeout(function() {
                            window.location.href = data.url;
                        }, 1800);
                    }
                }
            })
  }
}
})

//approval.js
define(['util'], function(util) {
   //筛选事件
   function screen(){
     $('.screen-li').click(function(){
       var screenText = $(this).html();
       var val = $(this).attr('data-val');
       var type = $('.approval-kind-checked').attr('data-kind');
       var keyword = $('.screen-input').val();
       $('.screen-li').removeClass('screen-li-checked');
       $(this).addClass('screen-li-checked');
       $('.screen-span em').text(screenText);
       $('.screen-span').trigger('click').attr('data-val',val);
       loadApproval($('#'+type+'').attr('data-type'),keyword,val);
     })
   }
   //加载领导审批申请数据
   function loadApproval(type,keyword,screen){
     $.ajax({
       url:approvalajax,
       type:'POST',
       dataType:'json',
       data:{type:type,keyword:keyword,screen:screen},
       success:function(data){
         var newData = data.info;
         var sum = data.url;
         if(newData.length>0 || newData!=""){
           var html = '';
           for(var i=0;i<newData.length;i++){
               var id = newData[i].id;//该条申请的id
               var head = newData[i].url;//头像
               var name = newData[i].name;//名字
               var kind = newData[i].kind;//类型（请假申请，采购申请等）
               var date = newData[i].time;//该条申请的时间
               var state = newData[i].state;//该条申请的状态
               var turnurl = newData[i].turnurl;//该条申请的状态
               html+='<li class="approval-li">';
               html+='<a href="'+turnurl+'" class="approval-a">';
               html+='<img src="'+head+'" class="approval-head" />';
               html+='<p class="approval-name">'+name+'的'+kind+'</p>';
               html+='<p class="approval-p">'+date+'</p>';
               if(state=='驳回'){
                 html+='<p class="approval-state approval-revoke">'+state+'</p>';
               }else{
                 html+='<p class="approval-state">'+state+'</p>';
               }
               html+='</a></li>';
             }
             if(sum==0){
              $('.approval-num').hide();
            }else{
               $('.approval-num').show();
             $('.approval-num').html(sum);
           }
           $('.approval-section[data-type="'+type+'"] ul').html(html);
         }else{
           $('.approval-num').hide();
          var noneHtml ='<div class="none-tip"><img src="'+imgurl+'" class="none-img"/><p class="none-text">暂无申请</p></div>';
          $('.approval-section[data-type="'+type+'"] ul').html(noneHtml);
        }
      }
    })
}
   //加载我的申请数据
   function loadMyApply(state,kind){
     $.ajax({
      url:initiatedajax,
      dataType:'json',
      type:'POST',
      data:{state:state,kind:kind},
      success:function(data){
        var newData = data.info;
        if(newData.length>0||newData!=''){
          var html='';
          for(var i=0;i<newData.length;i++){
                var id = newData[i].id;//该条申请的id
                var head = newData[i].url;//头像链接
                var name = newData[i].name;//用户名称
                var kind = newData[i].kind;//申请类型
                var date = newData[i].time;//申请时间
                var state = newData[i].state;//申请状态
                var turnrul = newData[i].turnrul;//申请状态
                html+='<li class="approval-li">';
                html+='<a href="'+turnrul+'" class="approval-a">';
                html+='<img src="'+head+'" class="approval-head" />';
                html+='<p class="approval-name">'+name+'的'+kind+'</p>';
                html+='<p class="approval-p">'+date+'</p>';
                if(state=='驳回'){
                  html+='<p class="approval-state approval-revoke">'+state+'</p>';
                }else{
                  html+='<p class="approval-state">'+state+'</p>';
                }
                html+='</a></li>';
              }
              $('.approval-list').html(html);
            }else{
              var noneHtml ='<div class="none-tip"><img src="'+imgurl+'" class="none-img"/><p class="none-text">暂无申请</p></div>';
              $('.approval-list').html(noneHtml);
            }
          }
        })
}
   //加载我的抄送数据
   function loadCopy(kind){
     $.ajax({
      url:copyajax,
      dataType:'json',
      type:'POST',
      data:{kind:kind},
      success:function(data){
        var newData = data.info;
        if(newData.length>0||newData!=''){
          var html='';
          for(var i=0;i<newData.length;i++){
                var id = newData[i].id;//该条申请的id
                var head = newData[i].url;//头像链接
                var name = newData[i].name;//用户名称
                var kind = newData[i].kind;//申请类型
                var date = newData[i].time;//申请时间
                var state = newData[i].state;//申请状态
                var turnrul = newData[i].turnrul;//申请状态
                html+='<li class="approval-li">';
                html+='<a href="'+turnrul+'" class="approval-a">';
                html+='<img src="'+head+'" class="approval-head" />';
                html+='<p class="approval-name">'+name+'的'+kind+'</p>';
                html+='<p class="approval-p">'+date+'</p>';
                if(state=='驳回'){
                  html+='<p class="approval-state approval-revoke">'+state+'</p>';
                }else{
                  html+='<p class="approval-state">'+state+'</p>';
                }
                html+='</a></li>';
              }
              $('.approval-list').html(html);
            }else{
              var noneHtml ='<div class="none-tip"><img src="'+imgurl+'" class="none-img"/><p class="none-text">暂无申请</p></div>';
              $('.approval-list').html(noneHtml);
            }
          }
        })
}
return{
  "screen":screen,
  "loadApproval":loadApproval,
  "loadMyApply":loadMyApply,
  "loadCopy":loadCopy
}
})

// JavaScript Document
var setTimeoutalltip;
//引入底部
function includeFooter(num){
	var html="";
		html+="<footer class=\"main_footer\">";
		html+="<a href=\"member_center.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe66c;</i><p>精选</p></a>";
		html+="<a href=\"sign.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe670;</i><p>发现</p></a>";
		html+="<a href=\"pointsShops.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe666;</i><p>购物车</p></a>";
		html+="<a href=\"member_ifrom.html\" class=\"main_footer_a\"><i class=\"iconfont\">&#xe66d;</i><p>我的</p></a>";
		html+="</footer>";
	$('body').append(html);
	$('.main_footer a').eq(num-1).addClass('active');
}
//引入禁止手机横屏
function includeMask(){
	var html="";
	    html+="<div class=\"mask flexcontainer\" id=\"all_mask\">";
			html+="<div class=\"mask-box\">";
			html+="<div class=\"mask-pic\">";
			html+="<i></i>";
			html+="</div>";
			html+="<span>为了更好的体验，请将手机/平板竖过来</span>";
			html+="</div>";
			html+="</div>";
	$('body').append(html);
}
//引入顶部
function includeToper(e){
	var html="";
		html+="<div class=\"Tops\">";
		html+="<a href=\"javascript:history.go(-1);\"><img src=\"img/back.png\"/></a>"+e+"<p></p>";
		html+="</div>";
	$('body').append(html);
}
//是否微信、pc
function is_weixn(){
    var ua = navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i)=="micromessenger") {
		//touchFade();
        return true;
    } else {
		//showFade();
    }
}
/*回到顶部*/
function backTop(view){
   $(''+view+'').animate({scrollTop:0},200);
}
//默认页面沉底方法
function tops(){
	$('.chats').scrollTop(1000000);
}
//操作提示
function alltip(text) {
    clearTimeout(setTimeoutalltip);
    $('.tipfade').hide();
    $('.tipfade').show();
    $('.tipspan').text(text).fadeInDown();
    setTimeoutalltip = setTimeout(function() { $('.tipfade').fadeOut(); }, 2000);
}

//轮播
function banner(){
  var swiper = new Swiper('.swiper-container', {
      pagination: '.swiper-pagination',
      paginationClickable: true,
      autoplay : 2000,
      autoplayDisableOnInteraction: false,//不禁用autoplay
	  loop:true,
      grabCursor:true,//抓手光标
  });
}
//向上弹出
jQuery.fn.slideUps = function () {
	var flag=$(this).hasClass('animated slideUp speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideUp speed');
	}else{
		ele.addClass('animated slideUp speed');
		setTimeout(function(){
			ele.css('transform','translateX(0%)');
			ele.removeClass('animated slideUp speed');
		},600);
	}
}
//向下收回
jQuery.fn.slideDowns = function () {
	var flag=$(this).hasClass('animated slideDown speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideDown speed');
	}else{
		ele.addClass('animated slideDown speed');
		setTimeout(function(){
			ele.css('transform','translateX(100%)');
			ele.removeClass('animated slideDown speed');
		},200);
	}
}
//向左边弹出
jQuery.fn.slideLeft = function () {
	var flag=$(this).hasClass('animated slideLeft speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideLeft speed');
	}else{
		ele.addClass('animated slideLeft speed');
		setTimeout(function(){
			ele.css('transform','translateX(0%)');
			ele.removeClass('animated slideLeft speed');
		},600);
	}
}
//向右边弹回
jQuery.fn.slideRight = function () {
	var flag=$(this).hasClass('animated slideRight speed');
	var ele=$(this);
	if(flag==true){
		ele.removeClass('animated slideRight speed');
	}else{
		ele.addClass('animated slideRight speed');
		setTimeout(function(){
			ele.css('transform','translateX(100%)');
			ele.removeClass('animated slideRight speed');
		},600);
	}
}
//渐入效果
jQuery.fn.fadeInDown = function () {
	var flag=$(this).hasClass('animated fadeInDown speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeInDown speed');
	}else{
		$(this).addClass('animated fadeInDown speed');
		setTimeout(function(){
			ele.removeClass('animated fadeInDown speed');
		},600);
	}
}
//弹性放大效果
jQuery.fn.bounceIn = function () {
	var flag=$(this).hasClass('animated bounceIn speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated bounceIn speed');
	}else{
		$(this).addClass('animated bounceIn speed');
		setTimeout(function(){
			ele.removeClass('animated bounceIn speed');
		},600);
	}
}
//渐出效果
jQuery.fn.fadeOutUp = function () {
	var flag=$(this).hasClass('animated fadeOutUp speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeOutUp speed');
	}else{
		$(this).addClass('animated fadeOutUp speed');
		setTimeout(function(){
			ele.hide().removeClass('animated fadeOutUp speed');
		},600);
	}
}
//从右渐入效果
jQuery.fn.fadeInRight = function () {
	var flag=$(this).hasClass('animated fadeInRight speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeInRight speed');
	}else{
		$(this).addClass('animated fadeInRight speed');
		setTimeout(function(){
			ele.removeClass('animated fadeInRight speed');
		},600);
	}
}
//向右渐出效果
jQuery.fn.fadeOutRight = function () {
	var flag=$(this).hasClass('animated fadeOutRight speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeOutRight speed');
	}else{
		$(this).addClass('animated fadeOutRight speed');
		setTimeout(function(){
			ele.hide().removeClass('animated fadeOutRight speed');
		},600);
	}
}
//向左渐出效果
jQuery.fn.fadeOutLeft = function () {
	var flag=$(this).hasClass('animated fadeOutLeft speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeOutLeft speed');
	}else{
		$(this).addClass('animated fadeOutLeft speed');
		setTimeout(function(){
			ele.hide().removeClass('animated fadeOutLeft speed');
		},600);
	}
}
//从左渐入效果
jQuery.fn.fadeInLeft = function () {
	var flag=$(this).hasClass('animated fadeInRight speed');
	var ele=$(this);
	if(flag==true){
		$(this).removeClass('animated fadeInLeft speed');
	}else{
		$(this).addClass('animated fadeInLeft speed');
		setTimeout(function(){
			ele.removeClass('animated fadeInLeft speed');
		},600);
	}
}

//
jQuery.fn.touched = function () {
	$(this).on('touchstart',function(){
		$(this).addClass('scaleBig');
	});
	$(this).on('touchend',function(){
		$(this).removeClass('scaleBig');
	})
}
//
jQuery.fn.touchedImg = function () {
	$(this).bind('click',function(){
		var imgSrc=$(this).attr('src');
		var ele=$(this);
		var html="";
			html+="<div class=\"fadeImg\">";
			html+="<a><img class=\"fadePic\" src=\" "+imgSrc+" \"/></a></div>";
		$('body').append(html);
		//touchEvent.doubleTap(ele);
	})
}
//把一个元素放在屏幕的中心位置：$(element).center();
jQuery.fn.center = function () {
	this.css('margin-top', ( $(window).height() - this.height() ) / 2 +$(window).scrollTop() + 'px');
	return;
}
//滑动定位
$.fn.smartFloat = function() { 
    var position = function(element) { 
        var top = element.position().top; //当前元素对象element距离浏览器上边缘的距离 
        var pos = element.css("position"); //当前元素距离页面document顶部的距离 
        $('.allbody').scroll(function() { //侦听滚动时 
            var scrolls = $(this).scrollTop(); 
            if (scrolls > top) { //如果滚动到页面超出了当前元素element的相对页面顶部的高度 
                if (window.XMLHttpRequest) { //如果不是ie6 
                    element.css({ //设置css 
                        position: "fixed", //固定定位,即不再跟随滚动 
                        top: 0 //距离页面顶部为0 
                    })
                } else { //如果是ie6 
                    element.css({ 
                        top: scrolls  //与页面顶部距离 
                    });     
                } 
             $('.article-ul').css({
							 height:'17rem',
						   overflow:'auto',
							 marginTop:'1rem'
					   });
            }else { 
                element.css({ //如果当前元素element未滚动到浏览器上边缘，则使用默认样式 
                    position: pos, 
                })
						 $('.article-ul').css({height:'auto',marginTop:'0',overflow:''});
            } 
        }); 
    }; 
    return $(this).each(function() { position($(this))}); 
}; 
//坐标
function joinCar(){
	var cont=$(".joinCar");
	var contW=$(".joinCar").width();
	var contH=$(".joinCar").height();
	var startX,startY,sX,sY,moveX,moveY;
	var winW=$(window).width();
	var winH=$(window).height();
	$(".joinCar").on({//绑定事件
		touchstart:function(e){
			startX = e.originalEvent.targetTouches[0].pageX;	//获取点击点的X坐标
			startY = e.originalEvent.targetTouches[0].pageY;    //获取点击点的Y坐标
			//console.log("startX="+startX+"************startY="+startY);
			sX=$(this).offset().left;//相对于当前窗口X轴的偏移量
			sY=$(this).offset().top;//相对于当前窗口Y轴的偏移量
			//console.log("sX="+sX+"***************sY="+sY);
			leftX=startX-sX;//鼠标所能移动的最左端是当前鼠标距div左边距的位置
			rightX=winW-contW+leftX;//鼠标所能移动的最右端是当前窗口距离减去鼠标距div最右端位置
			topY=startY-sY;//鼠标所能移动最上端是当前鼠标距div上边距的位置
			bottomY=winH-contH+topY;//鼠标所能移动最下端是当前窗口距离减去鼠标距div最下端位置
			},
		touchmove:function(e){
			e.preventDefault();
			moveX=e.originalEvent.targetTouches[0].pageX;//移动过程中X轴的坐标
			moveY=e.originalEvent.targetTouches[0].pageY;//移动过程中Y轴的坐标
			//console.log("moveX="+moveX+"************moveY="+moveY);
			if(moveX<leftX){moveX=leftX;}
			if(moveX>rightX){moveX=rightX;}
			if(moveY<topY){moveY=topY;}
			if(moveY>bottomY){moveY=bottomY;}
			$(this).css({
				"left":moveX+sX-startX,
				"top":moveY+sY-startY,
				})
			},
	})
}
//判断移动pc
function IsPC(){
   var userAgentInfo = navigator.userAgent;
   var Agents = new Array("Android", "iPhone", "SymbianOS", "Windows Phone", "iPad", "iPod");
   var flag = true;
   for (var v = 0; v < Agents.length; v++) {
	   if (userAgentInfo.indexOf(Agents[v]) > 0) { flag = false; break; }
   }
   if(flag==false){
   	   $('.iconfont').css('font-family','iconfont');
   }else{
   	   $('.iconfont').css('font-family','iconfont2');
   }

}
//横竖屏检测
// $(window).bind( 'orientationchange', function(e){
// 	orient();
// });

/*js判断手机横、竖屏*/
function orient() {
	if (window.orientation == 0 || window.orientation == 180) {
		//$("body").attr("class", "portrait");
		$('#mask').hide();
		orientation = 'portrait';
		console.log('竖屏');
		return false;
	}
	else if (window.orientation == 90 || window.orientation == -90) {
		//$("body").attr("class", "landscape");
		$('#mask').show();
		orientation = 'landscape';
		console.log('横屏');
		return false;
	}
}
//安卓input输入影响布局解决方案
function AndroidInput(ele){
	var viewHeight = window.innerHeight; //获取可视区域高度
	$("input").focus(function(){
	    $("."+ele+"").css("height",viewHeight);
			$('#all_mask').hide();
	}).blur(function(){
	    $("."+ele+"").css("height","100%");
	});
}
/*禁用页面滑动*/
function disabletouchmove(){
  $('body').bind('touchmove',function(e){ e.preventDefault();})
}
//加入购物车之抛物线运动及以下兼容IE9
jQuery.fn.joinCar = function (btn,cart) {
	btn.bind('click',function(event){
		var offset = cart.offset();//购物车位置
		var img = $(this).parent().find('img').attr('src');//获取当前点击图片链接
		var flyer = $('<span class="flyer-span"></span>');//抛物体对象
		cart.removeClass('animated carEnlarge');
		flyer.fly({
       start: {
			   left: event.pageX, //抛物体起点横坐标
			   top: event.pageY////抛物体起点纵坐标
       },
		   end: {
				 left: offset.left + 10, //抛物体终点横坐标
				 top: offset.top + 10, //抛物体终点纵坐标
		   },
		   onEnd: function() {
			  cart.addClass('animated carEnlarge');//成功加入购物车动画效果
				this.destory();//销毁抛物体
		   }
		});
	})
}
Array.prototype.remove=function(val){
	var index=this.indexOf(val);
	if(index>-1){
		this.splice(index,1);
	}
}
var hover=['imghvr-fade','imghvr-push-up','imghvr-push-down','imghvr-push-left','imghvr-push-right','imghvr-slide-up','imghvr-blur',
			'imghvr-slide-down','imghvr-slide-left','imghvr-slide-right','imghvr-reveal-up','imghvr-reveal-down','imghvr-reveal-left',
			'imghvr-reveal-right','imghvr-hinge-up','imghvr-hinge-down','imghvr-hinge-left','imghvr-hinge-right','imghvr-flip-horiz',
			'imghvr-flip-vert','imghvr-flip-diag-1','imghvr-flip-diag-2','imghvr-shutter-out-horiz','imghvr-shutter-out-vert',
			'imghvr-shutter-out-diag-1','imghvr-shutter-out-diag-2','imghvr-shutter-in-horiz','imghvr-shutter-in-vert',
			'imghvr-shutter-in-out-horiz','imghvr-shutter-in-out-vert','imghvr-shutter-in-out-diag-1','imghvr-shutter-in-out-diag-2',
			'imghvr-fold-up','imghvr-fold-down','imghvr-fold-left','imghvr-fold-right','imghvr-zoom-in','imghvr-zoom-out','imghvr-zoom-out-up',
			'imghvr-zoom-out-down','imghvr-zoom-out-left','imghvr-zoom-out-right','imghvr-zoom-out-flip-horiz','imghvr-zoom-out-flip-vert',
		  ]

jQuery.fn.hovers = function (ele) {
	$.each(ele.children('li'),function(index){
		var i=parseInt(44*Math.random());
		var classes=hover[i];
		ele.children('li').eq(index).addClass(classes);
	})
}

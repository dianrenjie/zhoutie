define( ['jquery','effect','util'] , function ($,effect,util) {
    return{
      intSmart:function(){
        $('.article-kind').smartFloat();
      },
      loadArticle:function(type,articleNo){
        $.ajax({
            url:loadLectureUrl,
            dataType:'json',
            type:'POST',
            data:{type:type,articleNo:articleNo},
            success:function(data){
              var articleData = data.info;
              if(articleData!=""||articleData.length>0){
                var html='';
                var afterNo = Number(articleNo);
                for(var i=0;i<articleData.length;i++){
                  var articleId = articleData[i].id; //文章的id
                  var articleImg = articleData[i].imageurl; //文章的图片路径
                  var articleTitle = articleData[i].title; //文章的图片路径
                  var articlTime = util.changeTimeStamp(articleData[i].addtime, 2); //文章的发布时间
                  var articleFrom = articleData[i].source; //文章的来源

                  html += "<li class=\"article-li\">";
                  html += "<a class=\"todetail\" href=\"" + articlDetailUrl + "?id=" + articleId + "\">";
                  html += "<img src=\"" + articleImg + "\" class=\"article-pic\" />";
                  html += "<p class=\"article-p article-title\">" + articleTitle + "</p>";
                  html += "<p class=\"article-p\">" + articlTime + "</p>";
                  html += "<p class=\"article-p\">" + articleFrom + "</p>";
                  html += "</a>";
                  html += "</li>";
                  afterNo++;
                }
                $('.article-list[data-type="'+type+'"] ul').append(html);
                $('.article-list[data-type="'+type+'"]').attr('data-articleNo',afterNo);
              }else{
                if(articleNo==0){
                  var noneHtml = "";
                  noneHtml += "<div class=\"article-none\">";
                  noneHtml += "<img src=\"/Public/wimg/barimage.bmp\" class=\"noneTip-img\"/>";
                  noneHtml += "<p class=\"noneTip-p\">暂时没有文章！</p></div>";
                  $('.article-list[data-type="'+type+'"] ul').html(noneHtml);
                }else{
                  $('.loading').remove();
                  $('.article-list[data-type="'+type+'"] ul').append('<div class="loading">没有更多内容了！</div>');
                  $('.article-list[data-type="'+type+'"] ul').off('scroll');
                }
              }
            }
        })
      }
    }
})

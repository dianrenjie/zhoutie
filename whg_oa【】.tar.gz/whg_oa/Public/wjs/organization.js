var codeTime = 60; //验证码间隔发送时间（秒）
var uploader;
define( ['jquery','upload','util','effect'] , function ($,WebUploader,util) {
 return{
   scaleClick:function(){
     $('.scale-p i').click(function(){
       var state = $(this).parent('.scale-p').attr('data-state');
       $('.scale-p').attr('data-state','false');
       $(this).parent('.scale-p').attr('data-state' ,'true');
       $('.scale-p i').html('');
       $(this).html('&#xe602;')
     })
   },
   intUploader:function(){
    var BASE_URL = '__PUBLIC__/js/wiz/js/webuploader/';
    uploader = WebUploader.create({
            // swf文件路径
            swf: 'http://cdn.staticfile.org/webuploader/0.1.0/Uploader.swf',
            // 文件接收服务端。
            // server: server,
            server: server,
            // 选择文件的按钮。可选。
            // 内部根据当前运行是创建，可能是input元素，也可能是flash.
            // 限制单张上传
            pick: {id:'#upload_btn',multiple: false },
            //队列中只允许存在一个文件
            fileNumLimit:1,
            // 选完文件后，是否自动上传。
            auto: false,
            // 不压缩image, 默认如果是jpeg，文件上传前会压缩一把再上传！
            resize: false,
            duplicate:true,
            accept :{
             title: 'Images',
             extensions: 'jpg,jpeg,bmp,png',
             mimeTypes: 'image/*'
           },
           thumbnailWidth:'1.8rem',
           thumbnailHeight:'1.8rem'
         })
    uploader.on( 'fileQueued', function( file ) {
      // uploader.removeFile(file);
      // for (var i = 0; i < uploader.getFiles().length; i++) {
      //   // 将图片从上传序列移除
      //   uploader.removeFile(uploader.getFiles()[i]);
      // }
      var $img = $('<img />');
      // $list为容器jQuery实例
      $('.preview-div').show().html( $img );

      // 创建缩略图
      // 如果为非图片文件，可以不用调用此方法。
      // thumbnailWidth x thumbnailHeight 为 100 x 100
      uploader.makeThumb( file, function( error, src ) {
        if ( error ) {
          $img.replaceWith('<span>不能预览</span>');
          return;
        }
        $img.attr( 'src', src );
      }, uploader.thumbnailWidth, uploader.thumbnailHeight );
    });
    uploader.on( 'uploadError', function( file ) {
       util.loadTip('上传出错！');
    });
    setTimeout(function(){ $('.webuploader-element-invisible').css('opacity',0); },200);
  },
  getCode:function(){
   var state = $('.personal-code').attr('data-state');
   var index = $('.article-checked').attr('data-id');
   if(state=="true"){
    if(index=="0"){
     var businessName = $.trim($('#businessName').val());
     var contact_g = $.trim($('#contact_g').val());
     var phone_g = $.trim($('#phone_g').val());
     if(businessName==""||contact_g==""||phone_g==""){
       util.loadTip('请填写企业名称、联系人、手机');
       return;
     }
     if(!(phonetest.test(phone_g))) {
       util.loadTip('请输入正确的手机号');
       return;
     }
     $.ajax({
       url:yanzhengurl,
       dataType: 'json',
       type: 'POST',
       data: { telephone: phone_g },
       success: function(data) {
         if (data.state == 1) {
           util.loadTip('验证码已发送,请注意查收');
           if (state == "true") {
             for (var i = 1; i <= codeTime; i++) {
               setTimeout("update_time(" + i + "," + codeTime + ")", i * 1000);
             }
           }
         } else {
           util.loadTip(data.msg);
         }
       }
     })
   }else{
     var streetName = $.trim($('#streetName').val());
     var community = $.trim($('#community').val());
     var contact_s = $.trim($('#contact_s').val());
     var phone_s = $.trim($('#phone_s').val());
     if(streetName==""||community==""||contact_s==""||phone_s==""){
      util.loadTip('请填写全部选项');
      return;
    }
    if(!(phonetest.test(phone_s))) {
     util.loadTip('请输入正确的手机号');
     return;
   }
   $.ajax({
     url:yanzhengurl,
     dataType: 'json',
     type: 'POST',
     data: { telephone: phone_s },
     success: function(data) {
       if (data.state == 1) {
         util.loadTip('验证码已发送,请注意查收');
         if (state == "true") {
           for (var i = 1; i <= codeTime; i++) {
             setTimeout("update_time(" + i + "," + codeTime + ")", i * 1000);
           }
         }
       } else {
         util.loadTip(data.msg);
       }
     }
   })
 }
}
},
subFrom:function(){
 var index = $('.article-checked').attr('data-id');
 if(index=="0"){
   var businessName = $.trim($('#businessName').val());
   var contact_g = $.trim($('#contact_g').val());
   var phone_g = $.trim($('#phone_g').val());
   var businessLicense = uploader.getFiles();
   var scale = $('.scale-p[data-state="true"]').find('span').html();
   var code_g = $.trim($('#code_g').val());
   var businessAddress = $.trim($('#businessAddress').val());
   var legalName = $.trim($('#legalName').val());
   var industry = $.trim($('#industry').val());
   var socialCode = $.trim($('#socialCode').val());
              //console.log(businessLicense);
             if(businessName==""||contact_g==""||phone_g==""){
               util.loadTip('请填写企业名称、联系人、手机');
               return;
             }
             if(!(phonetest.test(phone_g))) {
               util.loadTip('请输入正确的手机号');
               return;
             }
             if(businessLicense==""||businessLicense.length==0){
               util.loadTip('请上传营业执照');
               return;
             }
             if(code_g==""){
               util.loadTip('验证码不得为空');
               return;
             }
              uploader.upload();//执行上传方法
              // console.log(uploader.upload());
              //上传成功才执行ajax
              uploader.on( 'uploadSuccess', function( file,response ) {
                var imgurl = response.info;
                // console.log(response);
                // console.log(imgurl);
                $('.reg-btn').html('提交中...').attr('disabled', true);
                //企业工会ajax
                $.ajax({
                  url:organizationurl,
                  type:'POST',
                  dataType:'json',
                  data:{
                    name:businessName,
                    address:businessAddress,
                    legalperson:legalName,
                    type:industry,
                    linkman:contact_g,
                    phone:phone_g,
                    yzcode:code_g,
                    code:socialCode,
                    scale:scale,
                    img:imgurl,
                    classify:index
                  },
                  success:function(data){
                    if(data.status==1){
                      $('.tipfade').show();
                       $('.success-box').bounceIn();
                     }else{
                      util.loadTip(data.info);
                      $('.reg-btn').html('提交申请').attr('disabled', false);
                    }
                  }
                })
});
}else{
 var streetName = $.trim($('#streetName').val());
 var community = $.trim($('#community').val());
 var contact_s = $.trim($('#contact_s').val());
 var phone_s = $.trim($('#phone_s').val());
 var code_s = $.trim($('#code_s').val());
 if(streetName==""||community==""||contact_s==""||phone_s==""){
  util.loadTip('请填写全部选项');
  return;
}
if(!(phonetest.test(phone_s))) {
 util.loadTip('请输入正确的手机号');
 return;
}
if(code_s==""){
 util.loadTip('验证码不得为空');
 return;
}
$('.reg-btn').html('提交中...').attr('disabled', true);
         //社区工会ajax
         $.ajax({
           url:organizationurl,
           type:'POST',
           dataType:'json',
           data:{
             town:streetName,
             community:community,
             linkman:contact_s,
             phone:phone_s,
             classify:index,
             yzcode:code_s
           },
           success:function(data){
             if(data.status==1){
               $('.tipfade').show();
                $('.success-box').bounceIn();
             }else{
               util.loadTip(data.info);
               $('.reg-btn').html('提交申请').attr('disabled', false);
             }
           }
         })
       }
     }
   }
 })
